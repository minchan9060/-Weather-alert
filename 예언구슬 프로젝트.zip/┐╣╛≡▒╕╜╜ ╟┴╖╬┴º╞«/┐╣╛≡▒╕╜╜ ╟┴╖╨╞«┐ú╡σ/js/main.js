document.addEventListener("DOMContentLoaded", function () {
    const tabButtons = document.querySelectorAll(".tab-btn");
    const tabContents = document.querySelectorAll(".tab-content");
  
    // 🔹 탭 전환 기능
    tabButtons.forEach((button) => {
      button.addEventListener("click", () => {
        tabButtons.forEach((btn) => btn.classList.remove("active"));
        tabContents.forEach((content) => content.classList.remove("active"));
  
        button.classList.add("active");
        const tabId = button.getAttribute("data-tab");
        const targetTab = document.getElementById(tabId);
        if (targetTab) {
          targetTab.classList.add("active");
        } else {
          console.warn(`탭 ID '${tabId}'를 찾을 수 없습니다.`);
        }
      });
    });
  
    // 🔹 비밀번호 보기 토글
    const toggleButtons = document.querySelectorAll(".toggle-password");
    toggleButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const targetId = btn.getAttribute("data-target");
        const input = document.getElementById(targetId);
        if (input) {
          input.type = input.type === "password" ? "text" : "password";
        }
      });
    });
  
    // ===============================
    // 🚀 로그인 처리 (백엔드 연동)
    // ===============================
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
      loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const loginId = document.getElementById("loginId").value.trim();
        const loginPassword = document.getElementById("loginPassword").value.trim();
  
        try {
          const response = await fetch("http://127.0.0.1:8000/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username: loginId, password: loginPassword }),
          });
  
          if (response.ok) {
            alert("로그인 성공! 예언의 구슬이 당신의 패션 운명을 점치고 있습니다 🔮");
            // 로그인한 사용자 이름 저장 (설문조사 페이지에서 사용)
            localStorage.setItem("username", loginId);
            // ✅ 설문조사 페이지로 이동
            window.location.href = "survey/survey.html";
          } else {
            const data = await response.json();
            alert("로그인 실패: " + (data.detail || "서버 오류"));
          }
        } catch (error) {
          console.error(error);
          alert("서버 연결 오류 발생!");
        }
      });
    }
  
    // ===============================
    // 🧙 회원가입 처리 (백엔드 연동)
    // ===============================
    const signupForm = document.getElementById("signupForm");
    if (signupForm) {
      signupForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const signupId = document.getElementById("signupId").value.trim();
        const signupPassword = document.getElementById("signupPassword").value.trim();
        const confirmPassword = document.getElementById("confirmPassword").value.trim();
  
        if (signupPassword !== confirmPassword) {
          alert("비밀번호가 일치하지 않습니다!");
          return;
        }
  
        try {
          const response = await fetch("http://127.0.0.1:8000/auth/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              username: signupId,
              password: signupPassword,
            }),
          });
  
          if (response.ok) {
            alert("회원가입 성공! 로그인 탭으로 이동합니다.");
            const loginTab = document.querySelector('[data-tab="login"]');
            if (loginTab) loginTab.click();
          } else {
            const data = await response.json();
            alert("회원가입 실패: " + (data.detail || "서버 오류"));
          }
        } catch (error) {
          console.error(error);
          alert("서버 연결 실패!");
        }
      });
    }
  
    // ✅ 페이지가 처음 로드될 때 로그인 탭을 기본 활성화
    const defaultTab = document.querySelector('[data-tab="login"]');
    if (defaultTab) defaultTab.click();
  });
  