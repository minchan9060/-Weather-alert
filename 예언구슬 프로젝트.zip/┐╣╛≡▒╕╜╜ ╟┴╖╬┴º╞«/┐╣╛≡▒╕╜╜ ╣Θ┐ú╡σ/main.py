from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import Column, Integer, String, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from pydantic import BaseModel
import json

# ====================================
# ⚙️ 기본 설정
# ====================================
DATABASE_URL = "sqlite:///./test.db"  # ✅ SQLite 사용 (파일 자동 생성됨)

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

app = FastAPI()

# ====================================
# 🔓 CORS 설정 (프론트엔드 연결 허용)
# ====================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 모든 출처 허용
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ====================================
# 🧩 DB 모델
# ====================================
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True)
    password = Column(String)


class Survey(Base):
    __tablename__ = "surveys"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String)
    answers = Column(String)  # JSON 형태 문자열로 저장


Base.metadata.create_all(bind=engine)

# ====================================
# 🧩 Pydantic 스키마
# ====================================
class RegisterRequest(BaseModel):
    username: str
    password: str


class LoginRequest(BaseModel):
    username: str
    password: str


class SurveyRequest(BaseModel):
    username: str = None  # 로그인한 사용자 이름 (선택적)
    answers: dict


# ====================================
# 🧩 DB 종속성
# ====================================
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ====================================
# 👤 회원가입
# ====================================
@app.post("/auth/register")
def register_user(request: RegisterRequest, db: Session = Depends(get_db)):
    existing_user = db.query(User).filter(User.username == request.username).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Username already registered")

    user = User(username=request.username, password=request.password)
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"id": user.id, "username": user.username}


# ====================================
# 🔑 로그인
# ====================================
@app.post("/auth/login")
def login_user(request: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(
        User.username == request.username, User.password == request.password
    ).first()

    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password")

    return {"id": user.id, "username": user.username}


# ====================================
# 🧠 설문조사 응답 저장
# ====================================
@app.post("/survey")
async def save_survey(request: Request, db: Session = Depends(get_db)):
    data = await request.json()

    username = data.get("username", "unknown")
    answers = data.copy()
    if "username" in answers:
        del answers["username"]

    survey = Survey(username=username, answers=json.dumps(answers, ensure_ascii=False))
    db.add(survey)
    db.commit()

    return {"message": "✅ 설문조사가 성공적으로 저장되었습니다!", "username": username}


# ====================================
# 🏠 루트 (테스트용)
# ====================================
@app.get("/")
def root():
    return {"message": "🌤️ 예언구슬 FastAPI 서버 정상 작동 중!"}
