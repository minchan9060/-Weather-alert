// 탭 전환 기능
document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            // 모든 탭 버튼과 콘텐츠에서 active 클래스 제거
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // 클릭한 탭 버튼과 해당 콘텐츠에 active 클래스 추가
            button.classList.add('active');
            const tabId = button.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });

    // 비밀번호 표시/숨김 토글
    const toggleButtons = document.querySelectorAll('.toggle-password');
    toggleButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetId = button.getAttribute('data-target');
            const input = document.getElementById(targetId);
            const icon = button.querySelector('.eye-icon');

            if (input.type === 'password') {
                input.type = 'text';
                icon.textContent = '👁️‍🗨️';
            } else {
                input.type = 'password';
                icon.textContent = '👁️';
            }
        });
    });

    // 로그인 폼 유효성 검사 및 제출
    const loginForm = document.getElementById('loginForm');
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const loginId = document.getElementById('loginId').value.trim();
        const loginPassword = document.getElementById('loginPassword').value;

        // 유효성 검사
        let isValid = true;

        if (loginId === '') {
            showError('loginId', '아이디를 입력해주세요.');
            isValid = false;
        } else {
            clearError('loginId');
        }

        if (loginPassword === '') {
            showError('loginPassword', '비밀번호를 입력해주세요.');
            isValid = false;
        } else {
            clearError('loginPassword');
        }

        if (isValid) {
            // 로그인 성공 시뮬레이션
            showSuccessModal('로그인 성공! 🎉', `${loginId}님, 환영합니다!\n날씨 예언구슬이 당신을 기다리고 있어요.`);
            loginForm.reset();
        }
    });

    // 회원가입 폼 유효성 검사 및 제출
    const signupForm = document.getElementById('signupForm');
    signupForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const signupId = document.getElementById('signupId').value.trim();
        const nickname = document.getElementById('nickname').value.trim();
        const signupPassword = document.getElementById('signupPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const agreeTerms = document.getElementById('agreeTerms').checked;

        let isValid = true;

        // 아이디 검증 (4-20자 영문, 숫자)
        const idRegex = /^[a-zA-Z0-9]{4,20}$/;
        if (signupId === '') {
            showError('signupId', '아이디를 입력해주세요.');
            isValid = false;
        } else if (!idRegex.test(signupId)) {
            showError('signupId', '4-20자의 영문, 숫자만 사용 가능합니다.');
            isValid = false;
        } else {
            showSuccess('signupId');
        }

        // 닉네임 검증 (2-10자)
        if (nickname === '') {
            showError('nickname', '닉네임을 입력해주세요.');
            isValid = false;
        } else if (nickname.length < 2 || nickname.length > 10) {
            showError('nickname', '닉네임은 2-10자 이내로 입력해주세요.');
            isValid = false;
        } else {
            showSuccess('nickname');
        }

        // 비밀번호 검증 (8자 이상, 영문/숫자/특수문자)
        const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        if (signupPassword === '') {
            showError('signupPassword', '비밀번호를 입력해주세요.');
            isValid = false;
        } else if (!passwordRegex.test(signupPassword)) {
            showError('signupPassword', '8자 이상, 영문/숫자/특수문자를 포함해주세요.');
            isValid = false;
        } else {
            showSuccess('signupPassword');
        }

        // 비밀번호 확인 검증
        if (confirmPassword === '') {
            showError('confirmPassword', '비밀번호를 다시 입력해주세요.');
            isValid = false;
        } else if (signupPassword !== confirmPassword) {
            showError('confirmPassword', '비밀번호가 일치하지 않습니다.');
            isValid = false;
        } else {
            showSuccess('confirmPassword');
        }

        // 약관 동의 검증
        if (!agreeTerms) {
            alert('이용약관에 동의해주세요.');
            isValid = false;
        }

        if (isValid) {
            // 회원가입 성공 시뮬레이션
            showSuccessModal('회원가입 완료! ✨', `${nickname}님의 계정이 생성되었습니다.\n이제 날씨 예언구슬을 사용할 수 있어요!`);
            signupForm.reset();
        }
    });

    // 실시간 입력 검증
    document.getElementById('signupId').addEventListener('input', function(e) {
        const value = e.target.value.trim();
        const idRegex = /^[a-zA-Z0-9]{4,20}$/;
        
        if (value === '') {
            clearError('signupId');
        } else if (!idRegex.test(value)) {
            showError('signupId', '4-20자의 영문, 숫자만 사용 가능합니다.');
        } else {
            showSuccess('signupId');
        }
    });

    document.getElementById('nickname').addEventListener('input', function(e) {
        const value = e.target.value.trim();
        
        if (value === '') {
            clearError('nickname');
        } else if (value.length < 2 || value.length > 10) {
            showError('nickname', '닉네임은 2-10자 이내로 입력해주세요.');
        } else {
            showSuccess('nickname');
        }
    });

    document.getElementById('signupPassword').addEventListener('input', function(e) {
        const value = e.target.value;
        const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        
        if (value === '') {
            clearError('signupPassword');
        } else if (!passwordRegex.test(value)) {
            showError('signupPassword', '8자 이상, 영문/숫자/특수문자를 포함해주세요.');
        } else {
            showSuccess('signupPassword');
        }
    });

    document.getElementById('confirmPassword').addEventListener('input', function(e) {
        const value = e.target.value;
        const password = document.getElementById('signupPassword').value;
        
        if (value === '') {
            clearError('confirmPassword');
        } else if (password !== value) {
            showError('confirmPassword', '비밀번호가 일치하지 않습니다.');
        } else {
            showSuccess('confirmPassword');
        }
    });

    // 소셜 로그인 버튼 이벤트
    const socialButtons = document.querySelectorAll('.social-btn');
    socialButtons.forEach(button => {
        button.addEventListener('click', function() {
            const platform = this.classList.contains('kakao') ? '카카오' :
                           this.classList.contains('naver') ? '네이버' : '구글';
            showSuccessModal(`${platform} 로그인`, `${platform} 계정으로 연결 중입니다...`);
        });
    });

    // 아이디/비밀번호 찾기 링크
    const links = document.querySelectorAll('.link');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const text = this.textContent;
            showSuccessModal(`${text}`, `${text} 기능은 준비 중입니다.`);
        });
    });
});

// 에러 메시지 표시 함수
function showError(inputId, message) {
    const input = document.getElementById(inputId);
    const errorElement = input.closest('.input-group').querySelector('.error-message');
    
    input.classList.add('error');
    input.classList.remove('success');
    errorElement.textContent = message;
}

// 에러 메시지 제거 함수
function clearError(inputId) {
    const input = document.getElementById(inputId);
    const errorElement = input.closest('.input-group').querySelector('.error-message');
    
    input.classList.remove('error');
    input.classList.remove('success');
    errorElement.textContent = '';
}

// 성공 상태 표시 함수
function showSuccess(inputId) {
    const input = document.getElementById(inputId);
    const errorElement = input.closest('.input-group').querySelector('.error-message');
    
    input.classList.remove('error');
    input.classList.add('success');
    errorElement.textContent = '';
}

// 성공 모달 표시 함수
function showSuccessModal(title, message) {
    const modal = document.getElementById('successModal');
    const modalTitle = modal.querySelector('.modal-title');
    const modalMessage = modal.querySelector('.modal-message');
    const modalBtn = modal.querySelector('.modal-btn');

    modalTitle.textContent = title;
    modalMessage.textContent = message;
    modal.classList.add('show');

    // 모달 닫기 이벤트
    modalBtn.onclick = function() {
        modal.classList.remove('show');
    };

    // 모달 배경 클릭 시 닫기
    modal.onclick = function(e) {
        if (e.target === modal) {
            modal.classList.remove('show');
        }
    };
}
