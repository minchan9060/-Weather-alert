import os
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from app.database import engine
from app import models
from app.router import auth

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "app", "static")

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

app.include_router(auth.router, prefix="/auth", tags=["auth"])
STATIC_DIR = os.path.join(BASE_DIR, "app")

@app.get("/", response_class=HTMLResponse)
def read_root():
    index_path = os.path.join(STATIC_DIR, "static/index.html")
    with open(index_path, "r", encoding="utf-8") as f:
        return f.read()

@app.get("/auth", response_class=HTMLResponse)
def read_root():
    index_path = os.path.join(STATIC_DIR, "static/auth.html")
    with open(index_path, "r", encoding="utf-8") as f:
        return f.read()

@app.get("/sample", response_class=HTMLResponse)
def read_root():
    index_path = os.path.join(STATIC_DIR, "static/sample.html")
    with open(index_path, "r", encoding="utf-8") as f:
        return f.read()