const stat = document.querySelector(".btn");
