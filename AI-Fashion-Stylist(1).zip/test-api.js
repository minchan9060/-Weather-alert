/**
 * API 테스트 스크립트
 * 
 * 사용법:
 * node test-api.js
 */

const axios = require('axios');

const API_URL = 'http://localhost:3000';

// 테스트 데이터
const testData = {
    city: 'Seoul',
    userData: {
        age: 25,
        gender: '남성',
        preferredStyle: '캐주얼',
        recentActivity: '출근',
        bodyType: '보통',
        colorPreference: '검정, 화이트, 네이비'
    }
};

async function testHealthCheck() {
    console.log('🏥 헬스체크 테스트...');
    try {
        const response = await axios.get(`${API_URL}/api/health`);
        console.log('✅ 서버 정상:', response.data);
        return true;
    } catch (error) {
        console.error('❌ 서버 연결 실패:', error.message);
        console.error('   서버가 실행 중인지 확인하세요: npm start');
        return false;
    }
}

async function testRecommendation() {
    console.log('\n🤖 AI 추천 테스트...');
    console.log('요청 데이터:', JSON.stringify(testData, null, 2));
    
    try {
        const startTime = Date.now();
        const response = await axios.post(`${API_URL}/api/recommend`, testData);
        const endTime = Date.now();
        
        console.log(`\n✅ 추천 생성 완료 (${(endTime - startTime) / 1000}초)`);
        console.log('\n📊 응답 데이터:');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        
        // 날씨 정보
        console.log('\n🌤️  날씨 정보:');
        console.log(`   도시: ${response.data.weather.city}`);
        console.log(`   기온: ${response.data.weather.temperature}°C`);
        console.log(`   체감온도: ${response.data.weather.feelsLike}°C`);
        console.log(`   습도: ${response.data.weather.humidity}%`);
        console.log(`   풍속: ${response.data.weather.windSpeed} m/s`);
        console.log(`   불쾌지수: ${response.data.weather.discomfortIndex}`);
        console.log(`   날씨: ${response.data.weather.description}`);
        
        // 추천 요약
        console.log('\n💡 AI 추천:');
        console.log(`   ${response.data.recommendation.summary}`);
        console.log(`\n   추천 이유: ${response.data.recommendation.reason}`);
        
        // 스타일링 팁
        console.log('\n✨ 스타일링 팁:');
        response.data.recommendation.tips.forEach((tip, index) => {
            console.log(`   ${index + 1}. ${tip}`);
        });
        
        // 추천 아이템
        console.log('\n👔 추천 아이템:');
        response.data.recommendation.items.forEach((item, index) => {
            console.log(`\n   ${index + 1}. [${item.category}] ${item.itemName}`);
            console.log(`      ${item.description}`);
            console.log(`      🛒 ${item.shopLink}`);
        });
        
        console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        return true;
    } catch (error) {
        console.error('\n❌ 추천 생성 실패:');
        if (error.response) {
            console.error('   상태 코드:', error.response.status);
            console.error('   에러 메시지:', error.response.data.error || error.message);
        } else {
            console.error('   ', error.message);
        }
        return false;
    }
}

async function runTests() {
    console.log('╔════════════════════════════════════════╗');
    console.log('║   AI 패션 스타일리스트 API 테스트      ║');
    console.log('╚════════════════════════════════════════╝\n');
    
    // 헬스체크
    const healthOk = await testHealthCheck();
    if (!healthOk) {
        process.exit(1);
    }
    
    // 추천 테스트
    await testRecommendation();
    
    console.log('\n✨ 테스트 완료!\n');
}

// 스크립트 실행
runTests().catch(error => {
    console.error('테스트 중 오류 발생:', error);
    process.exit(1);
});
