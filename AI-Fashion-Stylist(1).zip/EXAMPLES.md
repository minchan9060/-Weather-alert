# 📚 사용 예제 모음

## 목차
1. [기본 사용 예제](#기본-사용-예제)
2. [다양한 시나리오](#다양한-시나리오)
3. [API 호출 예제](#api-호출-예제)
4. [커스터마이징 예제](#커스터마이징-예제)

---

## 기본 사용 예제

### 예제 1: 출근 코디 추천

**입력:**
- 도시: 서울
- 나이: 28세
- 성별: 남성
- 선호 스타일: 미니멀
- 체형: 보통
- 색상 선호도: 검정, 화이트, 그레이
- 오늘의 활동: 출근

**예상 결과:**
- 날씨: 20°C, 맑음
- 추천: 화이트 셔츠 + 그레이 슬랙스 + 블랙 로퍼

### 예제 2: 데이트 코디 추천

**입력:**
- 도시: 부산
- 나이: 24세
- 성별: 여성
- 선호 스타일: 페미닌
- 체형: 마른
- 색상 선호도: 파스텔 톤
- 오늘의 활동: 데이트

**예상 결과:**
- 날씨: 18°C, 흐림
- 추천: 플라워 패턴 원피스 + 가디건 + 스니커즈

---

## 다양한 시나리오

### 시나리오 1: 여름 무더위

```javascript
{
  "city": "Daegu",
  "userData": {
    "age": 22,
    "gender": "남성",
    "preferredStyle": "스트릿",
    "recentActivity": "캠퍼스 생활",
    "bodyType": "보통",
    "colorPreference": "다양함"
  }
}
```

**날씨 조건:** 32°C, 습도 75%, 불쾌지수 85
**AI 추천 포인트:**
- 통풍이 잘 되는 소재
- 밝은 색상으로 열 반사
- 모자, 선글라스 추천

### 시나리오 2: 겨울 한파

```javascript
{
  "city": "Seoul",
  "userData": {
    "age": 30,
    "gender": "여성",
    "preferredStyle": "클래식",
    "recentActivity": "출근",
    "bodyType": "보통",
    "colorPreference": "네이비, 카멜"
  }
}
```

**날씨 조건:** -5°C, 체감온도 -10°C, 풍속 5m/s
**AI 추천 포인트:**
- 롱 패딩 또는 코트
- 레이어링 제안
- 목도리, 장갑 필수

### 시나리오 3: 비 오는 날

```javascript
{
  "city": "Jeju",
  "userData": {
    "age": 26,
    "gender": "여성",
    "preferredStyle": "캐주얼",
    "recentActivity": "여행",
    "bodyType": "보통",
    "colorPreference": "다양함"
  }
}
```

**날씨 조건:** 15°C, 비, 습도 90%
**AI 추천 포인트:**
- 방수 재질의 아우터
- 레인부츠 또는 방수 스니커즈
- 우산 필수

---

## API 호출 예제

### JavaScript (Fetch API)

```javascript
async function getRecommendation() {
  try {
    const response = await fetch('http://localhost:3000/api/recommend', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        city: 'Seoul',
        userData: {
          age: 25,
          gender: '남성',
          preferredStyle: '캐주얼',
          recentActivity: '출근',
          bodyType: '보통',
          colorPreference: '다양함'
        }
      })
    });
    
    const data = await response.json();
    console.log('추천 결과:', data);
  } catch (error) {
    console.error('오류:', error);
  }
}

getRecommendation();
```

### Python (requests)

```python
import requests
import json

def get_recommendation():
    url = 'http://localhost:3000/api/recommend'
    
    data = {
        'city': 'Seoul',
        'userData': {
            'age': 25,
            'gender': '남성',
            'preferredStyle': '캐주얼',
            'recentActivity': '출근',
            'bodyType': '보통',
            'colorPreference': '다양함'
        }
    }
    
    try:
        response = requests.post(url, json=data)
        response.raise_for_status()
        result = response.json()
        print('추천 결과:', json.dumps(result, ensure_ascii=False, indent=2))
    except requests.exceptions.RequestException as e:
        print('오류:', e)

if __name__ == '__main__':
    get_recommendation()
```

### cURL

```bash
curl -X POST http://localhost:3000/api/recommend \
  -H "Content-Type: application/json" \
  -d '{
    "city": "Seoul",
    "userData": {
      "age": 25,
      "gender": "남성",
      "preferredStyle": "캐주얼",
      "recentActivity": "출근",
      "bodyType": "보통",
      "colorPreference": "다양함"
    }
  }'
```

---

## 커스터마이징 예제

### 1. 새로운 스타일 추가

`public/index.html` 수정:

```html
<select id="preferredStyle" name="preferredStyle" required>
    <option value="">선택하세요</option>
    <option value="캐주얼">캐주얼</option>
    <option value="스트릿">스트릿</option>
    <!-- 새로운 스타일 추가 -->
    <option value="아메카지">아메카지</option>
    <option value="시티보이">시티보이</option>
    <option value="Y2K">Y2K</option>
</select>
```

### 2. 추천 프롬프트 커스터마이징

`backend/server.js`의 `getOutfitRecommendation` 함수 수정:

```javascript
const prompt = `
당신은 전문 패션 스타일리스트입니다. 다음 정보를 바탕으로 맞춤형 옷차림을 추천해주세요.

**날씨 정보:**
- 도시: ${weatherData.city}
- 현재 기온: ${weatherData.temperature}°C
...

**추가 요구사항:**
- 지속 가능한 패션을 고려해주세요
- 가성비 좋은 제품을 우선적으로 추천해주세요
- 최신 트렌드를 반영해주세요
...
`;
```

### 3. 색상 테마 변경

`public/styles.css` 수정:

```css
:root {
    /* 블루 테마 */
    --primary-color: #667eea;
    --secondary-color: #764ba2;
    
    /* 그린 테마로 변경 */
    /* --primary-color: #56ab2f;
    --secondary-color: #a8e063; */
    
    /* 레드 테마로 변경 */
    /* --primary-color: #eb3349;
    --secondary-color: #f45c43; */
}
```

### 4. 무신사 외 다른 쇼핑몰 연동

`backend/server.js`의 `generateProductLinks` 함수 수정:

```javascript
function generateProductLinks(items) {
    return items.map(item => {
        // 여러 쇼핑몰 링크 생성
        return {
            ...item,
            shopLinks: {
                musinsa: `https://www.musinsa.com/search/musinsa/goods?q=${encodeURIComponent(item.searchKeyword)}`,
                wconcept: `https://www.wconcept.co.kr/Search?keyword=${encodeURIComponent(item.searchKeyword)}`,
                ably: `https://m.a-bly.com/goods/search?keyword=${encodeURIComponent(item.searchKeyword)}`
            }
        };
    });
}
```

### 5. 추천 아이템 수 변경

`backend/server.js`의 프롬프트 수정:

```javascript
// 기본 5개 (상의, 하의, 아우터, 신발, 액세서리)
// 3개로 줄이기
"items": [
    {
      "category": "상의",
      ...
    },
    {
      "category": "하의",
      ...
    },
    {
      "category": "신발",
      ...
    }
]
```

---

## 고급 사용 예제

### 배치 처리

여러 사용자에 대한 추천을 한 번에 생성:

```javascript
const users = [
  { age: 25, gender: '남성', preferredStyle: '캐주얼', recentActivity: '출근' },
  { age: 30, gender: '여성', preferredStyle: '미니멀', recentActivity: '회의' },
  { age: 22, gender: '남성', preferredStyle: '스트릿', recentActivity: '캠퍼스' }
];

async function batchRecommendations() {
  const promises = users.map(userData => 
    fetch('http://localhost:3000/api/recommend', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ city: 'Seoul', userData })
    }).then(res => res.json())
  );
  
  const results = await Promise.all(promises);
  console.log('배치 추천 완료:', results);
}
```

### 추천 결과 저장

```javascript
const fs = require('fs');

async function saveRecommendation(userData) {
  const response = await fetch('http://localhost:3000/api/recommend', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ city: 'Seoul', userData })
  });
  
  const data = await response.json();
  const filename = `recommendation_${Date.now()}.json`;
  
  fs.writeFileSync(filename, JSON.stringify(data, null, 2));
  console.log(`추천 결과 저장: ${filename}`);
}
```

---

## 테스트 데이터

### 테스트용 사용자 프로필

```javascript
const testProfiles = {
  // 20대 남성 직장인
  youngMaleProfessional: {
    age: 27,
    gender: '남성',
    preferredStyle: '미니멀',
    recentActivity: '출근',
    bodyType: '보통',
    colorPreference: '검정, 화이트, 네이비'
  },
  
  // 20대 여성 대학생
  youngFemaleStudent: {
    age: 21,
    gender: '여성',
    preferredStyle: '캐주얼',
    recentActivity: '캠퍼스 생활',
    bodyType: '마른',
    colorPreference: '파스텔 톤'
  },
  
  // 30대 남성 창업가
  malEntrepreneur: {
    age: 35,
    gender: '남성',
    preferredStyle: '스마트캐주얼',
    recentActivity: '미팅',
    bodyType: '통통한',
    colorPreference: '그레이, 네이비'
  },
  
  // 30대 여성 워킹맘
  femaleWorkingMom: {
    age: 33,
    gender: '여성',
    preferredStyle: '클래식',
    recentActivity: '출근',
    bodyType: '보통',
    colorPreference: '베이지, 브라운'
  }
};
```

---

## 에러 처리 예제

```javascript
async function getRecommendationWithErrorHandling() {
  try {
    const response = await fetch('http://localhost:3000/api/recommend', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        city: 'Seoul',
        userData: {
          age: 25,
          gender: '남성',
          preferredStyle: '캐주얼',
          recentActivity: '출근'
        }
      })
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || '추천 생성 실패');
    }
    
    const data = await response.json();
    return data;
    
  } catch (error) {
    if (error.message.includes('Failed to fetch')) {
      console.error('서버에 연결할 수 없습니다. 서버가 실행 중인지 확인하세요.');
    } else if (error.message.includes('Invalid API key')) {
      console.error('OpenAI API 키가 유효하지 않습니다.');
    } else {
      console.error('오류:', error.message);
    }
    throw error;
  }
}
```

---

**💡 팁:** 더 많은 예제와 자세한 사용법은 `README.md`와 `SETUP_GUIDE.md`를 참고하세요!
