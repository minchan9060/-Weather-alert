#!/bin/bash

# AI 패션 스타일리스트 실행 스크립트

echo "╔════════════════════════════════════════╗"
echo "║   AI 패션 스타일리스트 시작           ║"
echo "╚════════════════════════════════════════╝"
echo ""

# .env 파일 확인
if [ ! -f "backend/.env" ]; then
    echo "⚠️  경고: .env 파일이 없습니다."
    echo ""
    echo "다음 단계를 진행하세요:"
    echo "1. cd backend"
    echo "2. cp .env.example .env"
    echo "3. .env 파일에 API 키 입력"
    echo ""
    exit 1
fi

# backend 폴더로 이동
cd backend

# node_modules 확인
if [ ! -d "node_modules" ]; then
    echo "📦 의존성 설치 중..."
    npm install
    echo ""
fi

# 서버 실행
echo "🚀 서버 시작 중..."
echo "   접속 주소: http://localhost:3000"
echo ""
echo "   중지하려면 Ctrl + C 를 누르세요"
echo ""

npm start
