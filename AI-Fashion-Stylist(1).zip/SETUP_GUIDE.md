# 🚀 설치 및 실행 가이드

이 문서는 AI 패션 스타일리스트 시스템을 처음 설치하고 실행하는 방법을 단계별로 안내합니다.

## 📋 목차

1. [사전 준비](#사전-준비)
2. [설치 단계](#설치-단계)
3. [API 키 발급](#api-키-발급)
4. [환경 설정](#환경-설정)
5. [서버 실행](#서버-실행)
6. [테스트](#테스트)
7. [문제 해결](#문제-해결)

---

## 사전 준비

### 1. Node.js 설치

Node.js 14.0.0 이상이 필요합니다.

**설치 확인:**
```bash
node --version
npm --version
```

**설치되지 않은 경우:**
- [Node.js 공식 웹사이트](https://nodejs.org/)에서 LTS 버전 다운로드
- 설치 후 터미널/명령 프롬프트를 다시 시작

### 2. 텍스트 에디터

- [Visual Studio Code](https://code.visualstudio.com/) (추천)
- [Sublime Text](https://www.sublimetext.com/)
- 또는 선호하는 에디터

---

## 설치 단계

### Step 1: 프로젝트 폴더로 이동

```bash
cd fashion-recommender
```

### Step 2: 백엔드 의존성 설치

```bash
cd backend
npm install
```

설치되는 패키지:
- `express` - 웹 서버
- `cors` - CORS 설정
- `axios` - HTTP 클라이언트
- `openai` - OpenAI API 클라이언트
- `dotenv` - 환경 변수 관리

**예상 설치 시간:** 1-3분

---

## API 키 발급

### 1. OpenAI API 키 발급 (필수)

#### 단계:

1. **회원가입/로그인**
   - [OpenAI Platform](https://platform.openai.com/) 접속
   - Google, Microsoft, Apple 계정으로 간편 가입 가능

2. **API 키 생성**
   - 로그인 후 [API Keys 페이지](https://platform.openai.com/api-keys) 이동
   - "Create new secret key" 버튼 클릭
   - 키 이름 입력 (예: "Fashion Recommender")
   - 생성된 키를 **반드시 복사** (다시 확인 불가)

3. **결제 정보 등록**
   - [Billing 페이지](https://platform.openai.com/account/billing) 이동
   - 신용카드 등록 (무료 크레딧 소진 후 과금)
   - $5-10 정도 충전 권장

4. **사용량 모니터링**
   - [Usage 페이지](https://platform.openai.com/account/usage)에서 사용량 확인

**비용 예상:**
- GPT-4o-mini 모델 사용 시
- 추천 1회당 약 $0.01-0.03
- 100회 사용 시 약 $1-3

### 2. OpenWeatherMap API 키 발급 (필수)

#### 단계:

1. **회원가입**
   - [OpenWeatherMap](https://openweathermap.org/) 접속
   - "Sign Up" 클릭
   - 이메일, 비밀번호, 사용자명 입력
   - 이메일 인증 완료

2. **API 키 확인**
   - [API Keys 페이지](https://home.openweathermap.org/api_keys) 이동
   - 기본 제공되는 키 복사
   - 또는 "Generate" 버튼으로 새 키 생성

3. **키 활성화 대기**
   - ⚠️ **중요**: 생성 후 약 2시간 후부터 사용 가능
   - 즉시 사용 시 "Invalid API key" 오류 발생 가능

**무료 플랜:**
- 분당 60회 호출
- 하루 1,000,000회 호출
- 대부분의 사용에 충분

---

## 환경 설정

### Step 1: .env 파일 생성

```bash
# backend 폴더에서 실행
cp .env.example .env
```

Windows 명령 프롬프트:
```cmd
copy .env.example .env
```

### Step 2: .env 파일 편집

텍스트 에디터로 `backend/.env` 파일 열기:

```env
# OpenAI API 키
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxx

# OpenWeatherMap API 키
WEATHER_API_KEY=abcdef1234567890abcdef1234567890

# 서버 포트 (기본값: 3000)
PORT=3000
```

**주의사항:**
- `sk-proj-`로 시작하는 전체 OpenAI 키 입력
- 따옴표 없이 입력
- 공백 없이 입력

### Step 3: 환경 변수 확인

올바르게 설정되었는지 확인:

```bash
# Linux/Mac
cat .env

# Windows
type .env
```

---

## 서버 실행

### 개발 모드 실행 (권장)

자동 재시작 기능이 있는 개발 모드:

```bash
npm run dev
```

### 프로덕션 모드 실행

```bash
npm start
```

### 성공적인 실행 확인

터미널에 다음 메시지가 표시되어야 합니다:

```
🚀 패션 추천 서버가 포트 3000에서 실행 중입니다.
   - API 엔드포인트: http://localhost:3000/api/recommend
   - 웹 인터페이스: http://localhost:3000
```

---

## 테스트

### 1. 웹 브라우저 테스트

1. **브라우저 열기**
   ```
   http://localhost:3000
   ```

2. **정보 입력**
   - 도시: 서울
   - 나이: 25
   - 성별: 남성/여성
   - 선호 스타일: 캐주얼
   - 오늘의 활동: 출근

3. **"AI 추천 받기" 클릭**

4. **결과 확인**
   - 날씨 정보 표시
   - AI 추천 표시
   - 아이템 카드 표시

### 2. API 직접 테스트

#### cURL 사용 (Linux/Mac):

```bash
curl -X POST http://localhost:3000/api/recommend \
  -H "Content-Type: application/json" \
  -d '{
    "city": "Seoul",
    "userData": {
      "age": 25,
      "gender": "남성",
      "preferredStyle": "캐주얼",
      "recentActivity": "출근",
      "bodyType": "보통",
      "colorPreference": "다양함"
    }
  }'
```

#### PowerShell 사용 (Windows):

```powershell
$body = @{
    city = "Seoul"
    userData = @{
        age = 25
        gender = "남성"
        preferredStyle = "캐주얼"
        recentActivity = "출근"
        bodyType = "보통"
        colorPreference = "다양함"
    }
} | ConvertTo-Json

Invoke-RestMethod -Method Post -Uri "http://localhost:3000/api/recommend" `
  -ContentType "application/json" -Body $body
```

### 3. 헬스체크

```bash
curl http://localhost:3000/api/health
```

응답:
```json
{
  "status": "ok",
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```

---

## 문제 해결

### 문제 1: `npm install` 실패

**증상:**
```
npm ERR! code EACCES
```

**해결:**
```bash
# 권한 문제 - sudo 사용 (Linux/Mac)
sudo npm install

# 또는 npm 캐시 정리
npm cache clean --force
npm install
```

### 문제 2: 포트 이미 사용 중

**증상:**
```
Error: listen EADDRINUSE: address already in use :::3000
```

**해결:**

Option 1: 다른 포트 사용
```bash
PORT=3001 npm start
```

Option 2: 사용 중인 프로세스 종료
```bash
# Linux/Mac
lsof -ti:3000 | xargs kill -9

# Windows
netstat -ano | findstr :3000
taskkill /PID <PID번호> /F
```

### 문제 3: OpenAI API 키 오류

**증상:**
```
Error: Invalid API key
```

**해결:**
1. `.env` 파일에서 API 키 재확인
2. 키 앞뒤 공백 제거
3. OpenAI 계정에 결제 정보 등록 확인
4. [Usage 페이지](https://platform.openai.com/account/usage)에서 한도 확인

### 문제 4: 날씨 API 키 오류

**증상:**
```
Weather API error: Invalid API key
```

**해결:**
1. API 키 발급 후 2시간 이상 대기
2. [API Keys 페이지](https://home.openweathermap.org/api_keys)에서 키 상태 확인
3. 무료 플랜 사용량 초과 여부 확인

### 문제 5: CORS 오류

**증상:**
```
Access to fetch has been blocked by CORS policy
```

**해결:**
- `backend/server.js`에 CORS 설정 확인
- 브라우저 캐시 삭제
- 프라이빗 브라우징 모드에서 테스트

### 문제 6: 모듈을 찾을 수 없음

**증상:**
```
Error: Cannot find module 'express'
```

**해결:**
```bash
# node_modules 삭제 후 재설치
rm -rf node_modules
npm install
```

### 문제 7: .env 파일을 읽을 수 없음

**증상:**
```
OPENAI_API_KEY is undefined
```

**해결:**
1. `.env` 파일이 `backend` 폴더에 있는지 확인
2. 파일 권한 확인
3. 서버 재시작

---

## 추가 도움말

### 로그 확인

개발 모드에서 실시간 로그 확인:
```bash
npm run dev
```

### 디버깅 모드

더 자세한 로그 출력:
```bash
DEBUG=* npm start
```

### 서버 중지

실행 중인 서버 중지:
- `Ctrl + C` (Linux/Mac/Windows)

---

## 다음 단계

설치와 테스트가 완료되었다면:

1. **커스터마이징**: `README.md`의 커스터마이징 섹션 참고
2. **배포**: Vercel, Heroku 등으로 배포
3. **기능 추가**: 새로운 기능 개발

---

## 지원

문제가 해결되지 않는 경우:

1. 프로젝트 이슈 페이지 확인
2. 새로운 이슈 등록
3. 로그 전체 내용 첨부

---

**축하합니다! 🎉 이제 AI 패션 스타일리스트를 사용할 준비가 되었습니다!**
