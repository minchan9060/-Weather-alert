# 🌟 AI 패션 스타일리스트

OpenAI API를 활용한 날씨 기반 맞춤형 옷차림 추천 시스템

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Node](https://img.shields.io/badge/node-%3E%3D14.0.0-brightgreen.svg)
![OpenAI](https://img.shields.io/badge/OpenAI-GPT--4-orange.svg)

## ✨ 주요 기능

- 🌤️ **실시간 날씨 분석**: 현재 기온, 체감온도, 습도, 풍속, 불쾌지수를 종합적으로 분석
- 🤖 **AI 맞춤 추천**: OpenAI GPT-4를 활용한 개인화된 패션 코디 추천
- 👤 **사용자 프로필 기반**: 나이, 성별, 선호 스타일, 체형, 활동 정보를 고려한 추천
- 🛒 **즉시 구매 가능**: 무신사 연동으로 추천 아이템 바로 구매
- 📱 **반응형 디자인**: 모바일, 태블릿, 데스크톱 모든 환경에서 최적화
- ✨ **세련된 UI/UX**: 별 애니메이션과 유려한 인터랙션

## 🖼️ 스크린샷

```
┌─────────────────────────────────────────┐
│  ✨ AI 패션 스타일리스트                   │
│  날씨와 당신의 스타일에 맞는 완벽한 코디      │
├─────────────────────────────────────────┤
│  당신에 대해 알려주세요                    │
│  ┌──────┬──────┬──────┬──────┐           │
│  │ 도시 │ 나이 │ 성별 │ 체형 │           │
│  └──────┴──────┴──────┴──────┘           │
│  ✨ AI 추천 받기                         │
├─────────────────────────────────────────┤
│  ☀️ 서울 20°C                            │
│  체감온도: 18°C | 습도: 65% | 불쾌지수: 68 │
├─────────────────────────────────────────┤
│  💡 AI 스타일리스트 추천                  │
│  "오늘은 쾌적한 날씨로..."                │
├─────────────────────────────────────────┤
│  📦 추천 아이템                           │
│  [상의] [하의] [아우터] [신발] [액세서리]  │
│  🛒 무신사에서 구매하기                   │
└─────────────────────────────────────────┘
```

## 🚀 빠른 시작

### 필수 요구사항

- Node.js 14.0.0 이상
- npm 또는 yarn
- OpenAI API 키
- OpenWeatherMap API 키

### 설치

1. **저장소 클론 또는 다운로드**

```bash
cd fashion-recommender
```

2. **의존성 설치**

```bash
cd backend
npm install
```

3. **환경 변수 설정**

`.env.example` 파일을 `.env`로 복사하고 API 키를 입력하세요:

```bash
cp .env.example .env
```

`.env` 파일 편집:

```env
# OpenAI API 키 (https://platform.openai.com/api-keys)
OPENAI_API_KEY=sk-your-openai-api-key-here

# OpenWeatherMap API 키 (https://openweathermap.org/api)
WEATHER_API_KEY=your-weather-api-key-here

# 서버 포트 (기본값: 3000)
PORT=3000
```

### API 키 발급 방법

#### 1. OpenAI API 키
1. [OpenAI 플랫폼](https://platform.openai.com/)에 접속
2. 회원가입 또는 로그인
3. [API Keys 페이지](https://platform.openai.com/api-keys)로 이동
4. "Create new secret key" 클릭
5. 생성된 키를 복사하여 `.env` 파일에 입력

#### 2. OpenWeatherMap API 키
1. [OpenWeatherMap](https://openweathermap.org/)에 접속
2. 회원가입 (무료)
3. [API Keys 페이지](https://home.openweathermap.org/api_keys)로 이동
4. 기본 제공되는 키를 복사하거나 새로 생성
5. `.env` 파일에 입력

### 실행

```bash
# 개발 모드 (nodemon 사용)
npm run dev

# 프로덕션 모드
npm start
```

서버가 실행되면 브라우저에서 접속:
```
http://localhost:3000
```

## 📁 프로젝트 구조

```
fashion-recommender/
├── backend/
│   ├── server.js           # Express 서버 및 API 로직
│   ├── package.json        # 의존성 관리
│   └── .env               # 환경 변수 (생성 필요)
├── public/
│   ├── index.html         # 메인 HTML
│   ├── styles.css         # 스타일시트
│   └── app.js             # 프론트엔드 JavaScript
└── README.md              # 이 파일
```

## 🔧 API 엔드포인트

### POST `/api/recommend`

사용자 정보와 날씨를 기반으로 패션 추천을 생성합니다.

**요청 본문:**
```json
{
  "city": "Seoul",
  "userData": {
    "age": 25,
    "gender": "남성",
    "preferredStyle": "캐주얼",
    "recentActivity": "출근",
    "bodyType": "보통",
    "colorPreference": "다양함"
  }
}
```

**응답:**
```json
{
  "success": true,
  "weather": {
    "city": "Seoul",
    "temperature": 20,
    "feelsLike": 18,
    "humidity": 65,
    "windSpeed": 2.5,
    "discomfortIndex": 68,
    "weather": "Clear",
    "description": "맑음"
  },
  "recommendation": {
    "summary": "오늘은 쾌적한 날씨로...",
    "reason": "현재 기온이 20도로...",
    "tips": ["팁1", "팁2", "팁3"],
    "items": [
      {
        "category": "상의",
        "itemName": "오버핏 반팔티",
        "description": "편안한 착용감의...",
        "searchKeyword": "남성 오버핏 반팔티",
        "shopLink": "https://www.musinsa.com/...",
        "imageUrl": "/api/placeholder/상의"
      }
    ]
  }
}
```

### GET `/api/health`

서버 상태 확인

**응답:**
```json
{
  "status": "ok",
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```

## 🎨 커스터마이징

### 스타일 변경

`public/styles.css` 파일에서 CSS 변수를 수정하여 색상 테마를 변경할 수 있습니다:

```css
:root {
    --primary-color: #667eea;      /* 주 색상 */
    --secondary-color: #764ba2;    /* 보조 색상 */
    --accent-color: #f093fb;       /* 강조 색상 */
    /* ... */
}
```

### 추천 로직 조정

`backend/server.js`의 `getOutfitRecommendation` 함수에서 프롬프트를 수정하여 추천 스타일을 조정할 수 있습니다.

### 도시 추가

`public/index.html`의 도시 선택 드롭다운에 원하는 도시를 추가:

```html
<select id="city" name="city" required>
    <option value="Seoul">서울</option>
    <option value="New York">뉴욕</option>
    <!-- 새로운 도시 추가 -->
</select>
```

## 🌐 배포

### Vercel 배포

1. [Vercel](https://vercel.com/) 계정 생성
2. GitHub 저장소 연동
3. 환경 변수 설정 (OPENAI_API_KEY, WEATHER_API_KEY)
4. 배포

### Heroku 배포

```bash
# Heroku CLI 설치 후
heroku create your-app-name
heroku config:set OPENAI_API_KEY=your-key
heroku config:set WEATHER_API_KEY=your-key
git push heroku main
```

### Docker 배포

```dockerfile
FROM node:16
WORKDIR /app
COPY backend/package*.json ./
RUN npm install
COPY backend/ ./
COPY public/ ./public/
EXPOSE 3000
CMD ["node", "server.js"]
```

```bash
docker build -t fashion-recommender .
docker run -p 3000:3000 \
  -e OPENAI_API_KEY=your-key \
  -e WEATHER_API_KEY=your-key \
  fashion-recommender
```

## 🐛 트러블슈팅

### OpenAI API 오류

**문제**: `API key is invalid`
**해결**: 
- API 키가 올바른지 확인
- OpenAI 계정에 크레딧이 있는지 확인
- `.env` 파일이 올바른 위치에 있는지 확인

### 날씨 API 오류

**문제**: `Weather API error`
**해결**:
- OpenWeatherMap API 키 확인
- API 키가 활성화되었는지 확인 (발급 후 몇 시간 소요)
- 무료 플랜 사용량 초과 여부 확인

### CORS 오류

**문제**: `CORS policy error`
**해결**:
- `backend/server.js`에 CORS 설정이 있는지 확인
- 프론트엔드와 백엔드가 같은 포트에서 실행 중인지 확인

### 포트 충돌

**문제**: `Port 3000 is already in use`
**해결**:
```bash
# 다른 포트 사용
PORT=3001 npm start
```

## 📊 성능 최적화

- **캐싱**: 날씨 데이터를 일정 시간 캐싱하여 API 호출 감소
- **이미지 최적화**: WebP 포맷 사용
- **코드 분할**: 필요한 시점에만 리소스 로드
- **CDN 사용**: 정적 파일을 CDN에서 제공

## 🔒 보안 고려사항

1. **API 키 보호**: 
   - `.env` 파일을 `.gitignore`에 추가
   - 환경 변수로만 관리
   - 클라이언트 측에 노출 금지

2. **입력 검증**:
   - 서버 측에서 모든 입력 검증
   - SQL Injection, XSS 공격 방어

3. **Rate Limiting**:
   - API 호출 횟수 제한 구현
   - DDoS 공격 방어

## 📝 라이선스

MIT License

Copyright (c) 2024

## 👨‍💻 개발자

프로젝트에 대한 문의나 제안사항이 있으시면 이슈를 등록해주세요.

## 🙏 감사의 말

- OpenAI - GPT-4 API 제공
- OpenWeatherMap - 날씨 데이터 제공
- 무신사 - 패션 아이템 참고

## 📚 추가 자료

- [OpenAI API 문서](https://platform.openai.com/docs)
- [OpenWeatherMap API 문서](https://openweathermap.org/api)
- [Express.js 문서](https://expressjs.com/)
- [Node.js 문서](https://nodejs.org/)

---

**⭐ 이 프로젝트가 도움이 되었다면 Star를 눌러주세요!**
