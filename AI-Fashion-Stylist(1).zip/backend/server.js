const express = require('express');
const cors = require('cors');
const axios = require('axios');
const OpenAI = require('openai');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// OpenAI 클라이언트 초기화
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

// 날씨 API 키 (OpenWeatherMap 사용)
const WEATHER_API_KEY = process.env.WEATHER_API_KEY;

/**
 * 체감온도 계산 함수
 */
function calculateFeelsLike(temp, humidity, windSpeed) {
    // 실제 체감온도는 API에서 제공하지만, 커스텀 계산이 필요한 경우
    let feelsLike = temp;
    
    if (temp < 10 && windSpeed > 4.8) {
        // 바람 냉각 지수 (Wind Chill)
        feelsLike = 13.12 + 0.6215 * temp - 11.37 * Math.pow(windSpeed * 3.6, 0.16) + 0.3965 * temp * Math.pow(windSpeed * 3.6, 0.16);
    } else if (temp > 27 && humidity > 40) {
        // 열지수 (Heat Index)
        const T = temp;
        const RH = humidity;
        feelsLike = -8.78469475556 + 1.61139411 * T + 2.33854883889 * RH - 0.14611605 * T * RH 
                    - 0.012308094 * T * T - 0.0164248277778 * RH * RH + 0.002211732 * T * T * RH 
                    + 0.00072546 * T * RH * RH - 0.000003582 * T * T * RH * RH;
    }
    
    return Math.round(feelsLike * 10) / 10;
}

/**
 * 불쾌지수 계산 함수
 */
function calculateDiscomfortIndex(temp, humidity) {
    // DI = 0.81T + 0.01H(0.99T - 14.3) + 46.3
    const DI = 0.81 * temp + 0.01 * humidity * (0.99 * temp - 14.3) + 46.3;
    return Math.round(DI * 10) / 10;
}

/**
 * 날씨 정보 가져오기
 */
async function getWeatherData(city = 'Seoul') {
    try {
        const response = await axios.get(
            `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${WEATHER_API_KEY}&units=metric&lang=kr`
        );
        
        const data = response.data;
        const temp = data.main.temp;
        const humidity = data.main.humidity;
        const windSpeed = data.wind.speed;
        const feelsLike = data.main.feels_like;
        const discomfortIndex = calculateDiscomfortIndex(temp, humidity);
        
        return {
            city: data.name,
            temperature: Math.round(temp),
            feelsLike: Math.round(feelsLike),
            humidity: humidity,
            windSpeed: windSpeed,
            discomfortIndex: discomfortIndex,
            weather: data.weather[0].main,
            description: data.weather[0].description,
            icon: data.weather[0].icon
        };
    } catch (error) {
        console.error('날씨 정보 가져오기 실패:', error.message);
        // 기본값 반환
        return {
            city: city,
            temperature: 20,
            feelsLike: 20,
            humidity: 50,
            windSpeed: 2,
            discomfortIndex: 68,
            weather: 'Clear',
            description: '맑음',
            icon: '01d'
        };
    }
}

/**
 * OpenAI를 통한 옷차림 추천
 */
async function getOutfitRecommendation(weatherData, userData) {
    const prompt = `
당신은 전문 패션 스타일리스트입니다. 다음 정보를 바탕으로 맞춤형 옷차림을 추천해주세요.

**날씨 정보:**
- 도시: ${weatherData.city}
- 현재 기온: ${weatherData.temperature}°C
- 체감온도: ${weatherData.feelsLike}°C
- 습도: ${weatherData.humidity}%
- 풍속: ${weatherData.windSpeed} m/s
- 불쾌지수: ${weatherData.discomfortIndex} (68미만: 쾌적, 68-75: 보통, 75-80: 약간 불쾌, 80이상: 불쾌)
- 날씨 상태: ${weatherData.description}

**사용자 정보:**
- 나이: ${userData.age}세
- 성별: ${userData.gender}
- 선호 스타일: ${userData.preferredStyle}
- 최근 활동: ${userData.recentActivity}
- 체형: ${userData.bodyType || '보통'}
- 색상 선호도: ${userData.colorPreference || '다양함'}

다음 JSON 형식으로 응답해주세요:
{
  "recommendation": {
    "summary": "전체 추천 요약 (2-3문장)",
    "reason": "추천 이유 (날씨와 사용자 정보 기반)",
    "tips": ["팁1", "팁2", "팁3"]
  },
  "items": [
    {
      "category": "상의",
      "itemName": "구체적인 아이템 이름",
      "description": "아이템 설명",
      "searchKeyword": "무신사 검색용 키워드 (예: 남성 오버핏 반팔티)"
    },
    {
      "category": "하의",
      "itemName": "구체적인 아이템 이름",
      "description": "아이템 설명",
      "searchKeyword": "무신사 검색용 키워드"
    },
    {
      "category": "아우터",
      "itemName": "구체적인 아이템 이름",
      "description": "아이템 설명",
      "searchKeyword": "무신사 검색용 키워드"
    },
    {
      "category": "신발",
      "itemName": "구체적인 아이템 이름",
      "description": "아이템 설명",
      "searchKeyword": "무신사 검색용 키워드"
    },
    {
      "category": "액세서리",
      "itemName": "구체적인 아이템 이름",
      "description": "아이템 설명",
      "searchKeyword": "무신사 검색용 키워드"
    }
  ]
}

주의: 반드시 유효한 JSON만 반환하고, 마크다운이나 다른 텍스트는 포함하지 마세요.
`;

    try {
        const completion = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            messages: [
                {
                    role: "system",
                    content: "당신은 날씨와 사용자 정보를 분석하여 최적의 패션 추천을 제공하는 전문 스타일리스트입니다. 항상 유효한 JSON 형식으로만 응답합니다."
                },
                {
                    role: "user",
                    content: prompt
                }
            ],
            temperature: 0.7,
            max_tokens: 2000
        });

        const responseText = completion.choices[0].message.content.trim();
        
        // JSON 파싱 시도
        let recommendation;
        try {
            // 코드 블록이 있으면 제거
            const cleanedText = responseText.replace(/```json\n?/g, '').replace(/```\n?/g, '');
            recommendation = JSON.parse(cleanedText);
        } catch (parseError) {
            console.error('JSON 파싱 오류:', parseError);
            throw new Error('OpenAI 응답을 파싱할 수 없습니다.');
        }

        return recommendation;
    } catch (error) {
        console.error('OpenAI API 오류:', error.message);
        throw error;
    }
}

/**
 * 제품 검색 (무신사 스타일 검색 URL 생성)
 */
function generateProductLinks(items) {
    return items.map(item => {
        // 무신사 검색 URL 생성
        const searchUrl = `https://www.musinsa.com/search/musinsa/goods?q=${encodeURIComponent(item.searchKeyword)}`;
        
        return {
            ...item,
            shopLink: searchUrl,
            // 이미지는 프론트엔드에서 플레이스홀더 또는 실제 API로 처리
            imageUrl: `/api/placeholder/${item.category}`
        };
    });
}

/**
 * 메인 추천 API 엔드포인트
 */
app.post('/api/recommend', async (req, res) => {
    try {
        const { city, userData } = req.body;
        
        // 입력 검증
        if (!userData || !userData.age || !userData.gender || !userData.preferredStyle) {
            return res.status(400).json({
                error: '사용자 정보가 불완전합니다. age, gender, preferredStyle은 필수입니다.'
            });
        }

        // 1. 날씨 정보 가져오기
        console.log('날씨 정보 조회 중...');
        const weatherData = await getWeatherData(city || 'Seoul');

        // 2. OpenAI로 추천 받기
        console.log('AI 추천 생성 중...');
        const recommendation = await getOutfitRecommendation(weatherData, userData);

        // 3. 제품 링크 생성
        const itemsWithLinks = generateProductLinks(recommendation.items);

        // 4. 최종 응답
        res.json({
            success: true,
            weather: weatherData,
            recommendation: {
                ...recommendation.recommendation,
                items: itemsWithLinks
            }
        });

    } catch (error) {
        console.error('추천 API 오류:', error);
        res.status(500).json({
            success: false,
            error: error.message || '추천을 생성하는 중 오류가 발생했습니다.'
        });
    }
});

/**
 * 플레이스홀더 이미지 API
 */
app.get('/api/placeholder/:category', (req, res) => {
    const { category } = req.params;
    const placeholders = {
        '상의': 'https://via.placeholder.com/300x400/4A90E2/ffffff?text=Top',
        '하의': 'https://via.placeholder.com/300x400/7B68EE/ffffff?text=Bottoms',
        '아우터': 'https://via.placeholder.com/300x400/50C878/ffffff?text=Outer',
        '신발': 'https://via.placeholder.com/300x400/FF6B6B/ffffff?text=Shoes',
        '액세서리': 'https://via.placeholder.com/300x400/FFD700/ffffff?text=Accessory'
    };
    
    res.redirect(placeholders[category] || 'https://via.placeholder.com/300x400');
});

/**
 * 헬스체크 엔드포인트
 */
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// 서버 시작
app.listen(PORT, () => {
    console.log(`🚀 패션 추천 서버가 포트 ${PORT}에서 실행 중입니다.`);
    console.log(`   - API 엔드포인트: http://localhost:${PORT}/api/recommend`);
    console.log(`   - 웹 인터페이스: http://localhost:${PORT}`);
});

module.exports = app;
