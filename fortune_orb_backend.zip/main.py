from fastapi import FastAPI
from app import models, database
from app.auth import router as auth_router

models.Base.metadata.create_all(bind=database.engine)

app = FastAPI()

app.include_router(auth_router, prefix="/auth", tags=["Authentication"])

@app.get("/")
def root():
    return {"message": "예언구슬 API 서버 정상 작동 중!"}
