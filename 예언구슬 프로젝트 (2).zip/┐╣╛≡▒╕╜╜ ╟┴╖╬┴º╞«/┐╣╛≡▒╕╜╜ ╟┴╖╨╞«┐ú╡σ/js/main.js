
// 🌟 예언구슬 로그인 & 회원가입 + FastAPI 백엔드 연동 완성본
document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    // 🔹 탭 전환
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            button.classList.add('active');
            const tabId = button.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });

    // 👁 비밀번호 표시/숨김
    const toggleButtons = document.querySelectorAll('.toggle-password');
    toggleButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetId = button.getAttribute('data-target');
            const input = document.getElementById(targetId);
            const icon = button.querySelector('.eye-icon');

            if (input.type === 'password') {
                input.type = 'text';
                icon.textContent = '👁️‍🗨️';
            } else {
                input.type = 'password';
                icon.textContent = '👁️';
            }
        });
    });

    // ================================
    // 🚀 로그인 (FastAPI 연동)
    // ================================
    const loginForm = document.getElementById('loginForm');
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const loginId = document.getElementById('loginId').value.trim();
        const loginPassword = document.getElementById('loginPassword').value;

        if (!loginId || !loginPassword) {
            alert("아이디와 비밀번호를 입력해주세요.");
            return;
        }

        try {
            const response = await fetch("http://127.0.0.1:8000/auth/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    username: loginId,
                    password: loginPassword
                })
            });

            if (response.ok) {
                const data = await response.json();
                console.log("✅ 로그인 성공:", data);
                showSuccessModal('로그인 성공! 🎉', `${loginId}님, 환영합니다!`);
                setTimeout(() => {
                    window.location.href = "main_page/main.html";
                }, 1500);
            } else {
                const err = await response.json();
                alert(`로그인 실패 ❌\n${err.detail || '아이디 또는 비밀번호가 올바르지 않습니다.'}`);
            }
        } catch (error) {
            alert("서버 연결 실패 ❌\nFastAPI 서버가 실행 중인지 확인해주세요.");
            console.error("로그인 오류:", error);
        }
    });

    // ================================
    // ✨ 회원가입 (FastAPI 연동)
    // ================================
    const signupForm = document.getElementById('signupForm');
    signupForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const signupId = document.getElementById('signupId').value.trim();
        const nickname = document.getElementById('nickname').value.trim();
        const signupPassword = document.getElementById('signupPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const agreeTerms = document.getElementById('agreeTerms').checked;

        const idRegex = /^[a-zA-Z0-9]{4,20}$/;
        const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

        // 유효성 검사
        if (!idRegex.test(signupId)) return alert("❌ 아이디는 4~20자의 영문 또는 숫자만 가능합니다.");
        if (nickname.length < 2 || nickname.length > 10) return alert("❌ 닉네임은 2~10자 이내로 입력해주세요.");
        if (!passwordRegex.test(signupPassword)) return alert("❌ 비밀번호는 8자 이상, 영문/숫자/특수문자를 포함해야 합니다.");
        if (signupPassword !== confirmPassword) return alert("❌ 비밀번호가 일치하지 않습니다.");
        if (!agreeTerms) return alert("❌ 이용약관에 동의해주세요.");

        try {
            const response = await fetch("http://127.0.0.1:8000/auth/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    username: signupId,
                    password: signupPassword
                })
            });

            if (response.ok) {
                const data = await response.json();
                console.log("✅ 회원가입 성공:", data);
                showSuccessModal('회원가입 완료! ✨', `${nickname}님의 계정이 생성되었습니다.`);
            
                // ✅ 1. 설문조사 페이지로 이동 (2초 뒤 자동 이동)
                setTimeout(() => {
                    window.location.href = "../survey/survey.html?username=" + encodeURIComponent(signupId);
                }, 1500);
            }
            } else {
                const err = await response.json();
                alert(`회원가입 실패 ❌\n${err.detail || '이미 존재하는 아이디일 수 있습니다.'}`);
            }
        } catch (error) {
            alert("서버 연결 실패 ❌\nFastAPI 서버가 실행 중인지 확인해주세요.");
            console.error("회원가입 오류:", error);
        }
    });
});

// ================================
// 🧩 공통 함수 (에러 / 성공 모달)
// ================================
function showSuccessModal(title, message) {
    const modal = document.getElementById('successModal');
    const modalTitle = modal.querySelector('.modal-title');
    const modalMessage = modal.querySelector('.modal-message');
    const modalBtn = modal.querySelector('.modal-btn');

    modalTitle.textContent = title;
    modalMessage.textContent = message;
    modal.classList.add('show');

    modalBtn.onclick = function() { modal.classList.remove('show'); };
    modal.onclick = function(e) { if (e.target === modal) modal.classList.remove('show'); };
}