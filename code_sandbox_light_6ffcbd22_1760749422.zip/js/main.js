// 메인 애플리케이션 로직

class CrystalBallApp {
    constructor() {
        this.crystalBall = document.getElementById('crystalBall');
        this.fogOverlay = document.getElementById('fogOverlay');
        this.progressFill = document.getElementById('progressFill');
        this.rubProgress = document.getElementById('rubProgress');
        this.weatherInfo = document.getElementById('weatherInfo');
        this.loadingOverlay = document.getElementById('loadingOverlay');
        this.errorMessage = document.getElementById('errorMessage');
        
        this.rubProgress_value = 0;
        this.maxRubProgress = 100;
        this.isRubbing = false;
        this.lastMousePos = { x: 0, y: 0 };
        this.weatherData = null;
        
        this.init();
    }

    async init() {
        // 이벤트 리스너 설정
        this.setupEventListeners();
        
        // 날씨 정보 가져오기
        await this.loadWeatherData();
    }

    setupEventListeners() {
        // 마우스 이벤트
        this.crystalBall.addEventListener('mousedown', this.onRubStart.bind(this));
        this.crystalBall.addEventListener('mousemove', this.onRubMove.bind(this));
        this.crystalBall.addEventListener('mouseup', this.onRubEnd.bind(this));
        this.crystalBall.addEventListener('mouseleave', this.onRubEnd.bind(this));
        
        // 터치 이벤트
        this.crystalBall.addEventListener('touchstart', this.onTouchStart.bind(this));
        this.crystalBall.addEventListener('touchmove', this.onTouchMove.bind(this));
        this.crystalBall.addEventListener('touchend', this.onRubEnd.bind(this));
        
        // 별 효과 위치 랜덤화
        this.randomizeSparkles();
    }

    // 반짝임 효과 위치 랜덤화
    randomizeSparkles() {
        const sparkles = this.crystalBall.querySelectorAll('.sparkle');
        sparkles.forEach(sparkle => {
            const randomX = Math.random() * 80 + 10; // 10% ~ 90%
            const randomY = Math.random() * 80 + 10;
            sparkle.style.left = `${randomX}%`;
            sparkle.style.top = `${randomY}%`;
        });
        
        // 주기적으로 위치 변경
        setInterval(() => {
            this.randomizeSparkles();
        }, 3000);
    }

    // 문지르기 시작 (마우스)
    onRubStart(e) {
        if (this.rubProgress_value >= this.maxRubProgress) return;
        
        this.isRubbing = true;
        this.lastMousePos = { x: e.clientX, y: e.clientY };
    }

    // 문지르기 이동 (마우스)
    onRubMove(e) {
        if (!this.isRubbing) return;
        
        const currentPos = { x: e.clientX, y: e.clientY };
        const distance = this.calculateDistance(this.lastMousePos, currentPos);
        
        // 거리에 비례해서 진행도 증가
        this.increaseProgress(distance * 0.5);
        
        this.lastMousePos = currentPos;
    }

    // 문지르기 시작 (터치)
    onTouchStart(e) {
        if (this.rubProgress_value >= this.maxRubProgress) return;
        
        e.preventDefault();
        this.isRubbing = true;
        const touch = e.touches[0];
        this.lastMousePos = { x: touch.clientX, y: touch.clientY };
    }

    // 문지르기 이동 (터치)
    onTouchMove(e) {
        if (!this.isRubbing) return;
        
        e.preventDefault();
        const touch = e.touches[0];
        const currentPos = { x: touch.clientX, y: touch.clientY };
        const distance = this.calculateDistance(this.lastMousePos, currentPos);
        
        this.increaseProgress(distance * 0.5);
        
        this.lastMousePos = currentPos;
    }

    // 문지르기 종료
    onRubEnd() {
        this.isRubbing = false;
    }

    // 두 점 사이 거리 계산
    calculateDistance(pos1, pos2) {
        const dx = pos2.x - pos1.x;
        const dy = pos2.y - pos1.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    // 진행도 증가
    increaseProgress(amount) {
        this.rubProgress_value = Math.min(this.rubProgress_value + amount, this.maxRubProgress);
        this.updateProgress();
    }

    // 진행도 UI 업데이트
    updateProgress() {
        this.progressFill.style.width = `${this.rubProgress_value}%`;
        
        // 흐림 오버레이 투명도 조정
        const opacity = 1 - (this.rubProgress_value / this.maxRubProgress);
        this.fogOverlay.style.opacity = opacity;
        
        // 완료 시
        if (this.rubProgress_value >= this.maxRubProgress) {
            this.onRubComplete();
        }
    }

    // 문지르기 완료
    onRubComplete() {
        console.log('구슬 문지르기 완료!');
        
        // 진행도 바 숨기기
        setTimeout(() => {
            this.rubProgress.classList.add('hidden');
        }, 500);
        
        // 날씨 정보 표시
        setTimeout(() => {
            this.displayWeatherInfo();
        }, 800);
        
        // 날씨 애니메이션 표시
        if (this.weatherData) {
            WeatherAnimations.selectAnimation(
                this.weatherData.icon, 
                this.weatherData.weatherMain
            );
        }
    }

    // 날씨 데이터 로드
    async loadWeatherData() {
        try {
            this.loadingOverlay.classList.remove('hidden');
            
            // 날씨 정보 가져오기
            this.weatherData = await WeatherAPI.fetchWeather();
            
            console.log('날씨 데이터:', this.weatherData);
            
            // 로딩 완료
            setTimeout(() => {
                this.loadingOverlay.classList.add('hidden');
            }, 1000);
            
        } catch (error) {
            console.error('날씨 데이터 로드 실패:', error);
            this.showError();
        }
    }

    // 날씨 정보 표시
    displayWeatherInfo() {
        if (!this.weatherData) {
            console.error('날씨 데이터가 없습니다.');
            return;
        }

        // 위치
        const locationName = this.weatherData.city || WeatherAPI.currentLocation.city || '알 수 없음';
        document.getElementById('locationName').textContent = locationName;

        // 온도
        document.getElementById('temperature').textContent = `${this.weatherData.temperature}°C`;

        // 날씨 설명
        const description = this.weatherData.weatherDescription || this.getWeatherDescription(this.weatherData.weatherMain);
        document.getElementById('weatherDescription').textContent = description;

        // 습도
        document.getElementById('humidity').textContent = `${this.weatherData.humidity}%`;

        // 풍속
        document.getElementById('windSpeed').textContent = `${this.weatherData.windSpeed} m/s`;

        // 체감온도
        const feelsLike = this.weatherData.feelsLike || this.weatherData.temperature;
        document.getElementById('feelsLike').textContent = `${feelsLike}°C`;

        // API 출처
        document.getElementById('sourceName').textContent = this.weatherData.source || 'OpenWeather';

        // 날씨 정보 표시
        this.weatherInfo.classList.add('visible');
    }

    // 날씨 상태에 따른 한글 설명
    getWeatherDescription(weatherMain) {
        const descriptions = {
            'Clear': '맑음',
            'Clouds': '구름 많음',
            'Rain': '비',
            'Drizzle': '이슬비',
            'Snow': '눈',
            'Thunderstorm': '천둥번개',
            'Mist': '안개',
            'Fog': '안개',
            'Haze': '실안개',
            'Smoke': '연무',
            'Dust': '먼지',
            'Sand': '황사'
        };
        
        return descriptions[weatherMain] || weatherMain;
    }

    // 에러 표시
    showError() {
        this.loadingOverlay.classList.add('hidden');
        this.errorMessage.classList.add('visible');
    }
}

// 앱 시작
document.addEventListener('DOMContentLoaded', () => {
    window.app = new CrystalBallApp();
    
    console.log('🔮 날씨 예언 구슬 앱이 시작되었습니다!');
    console.log('💡 API 키 설정 안내:');
    console.log('1. OpenWeather API: https://openweathermap.org/api');
    console.log('2. 기상청 API: https://www.data.go.kr/');
    console.log('3. js/weather-api.js 파일에서 API 키를 설정하세요.');
    console.log('4. API 키가 없으면 데모 데이터가 표시됩니다.');
});
