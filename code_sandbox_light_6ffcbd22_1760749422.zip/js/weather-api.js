// 날씨 API 통합 및 교차 검증

const WeatherAPI = {
    // API 설정 (사용자가 자신의 API 키를 입력해야 함)
    OPENWEATHER_API_KEY: 'YOUR_OPENWEATHER_API_KEY_HERE',
    KMA_API_KEY: 'YOUR_KMA_API_KEY_HERE',
    
    // 현재 위치 정보
    currentLocation: {
        lat: null,
        lon: null,
        city: null
    },

    // 사용자 위치 가져오기
    getUserLocation: async function() {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject(new Error('브라우저가 위치 정보를 지원하지 않습니다.'));
                return;
            }

            navigator.geolocation.getCurrentPosition(
                (position) => {
                    this.currentLocation.lat = position.coords.latitude;
                    this.currentLocation.lon = position.coords.longitude;
                    resolve(this.currentLocation);
                },
                (error) => {
                    // 위치 거부 시 서울을 기본값으로
                    console.warn('위치 접근 거부됨. 서울을 기본 위치로 설정합니다.', error);
                    this.currentLocation.lat = 37.5665;
                    this.currentLocation.lon = 126.9780;
                    this.currentLocation.city = '서울';
                    resolve(this.currentLocation);
                }
            );
        });
    },

    // OpenWeather API에서 날씨 가져오기
    getOpenWeatherData: async function(lat, lon) {
        try {
            // API 키가 설정되지 않은 경우 데모 데이터 반환
            if (this.OPENWEATHER_API_KEY === 'YOUR_OPENWEATHER_API_KEY_HERE') {
                console.warn('OpenWeather API 키가 설정되지 않았습니다. 데모 데이터를 사용합니다.');
                return this.getDemoData();
            }

            const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${this.OPENWEATHER_API_KEY}&units=metric&lang=kr`;
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error(`OpenWeather API 오류: ${response.status}`);
            }
            
            const data = await response.json();
            
            return {
                source: 'OpenWeather',
                temperature: Math.round(data.main.temp),
                feelsLike: Math.round(data.main.feels_like),
                humidity: data.main.humidity,
                windSpeed: data.wind.speed,
                weatherMain: data.weather[0].main,
                weatherDescription: data.weather[0].description,
                city: data.name,
                icon: data.weather[0].icon
            };
        } catch (error) {
            console.error('OpenWeather API 오류:', error);
            return null;
        }
    },

    // 기상청 API에서 날씨 가져오기
    getKMAData: async function(lat, lon) {
        try {
            // API 키가 설정되지 않은 경우 null 반환
            if (this.KMA_API_KEY === 'YOUR_KMA_API_KEY_HERE') {
                console.warn('기상청 API 키가 설정되지 않았습니다.');
                return null;
            }

            // 기상청 API는 격자 좌표로 변환 필요
            const grid = this.convertToGrid(lat, lon);
            
            // 초단기실황 API 호출
            const baseUrl = 'http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst';
            const now = new Date();
            const baseDate = this.formatDate(now);
            const baseTime = this.formatTime(now);
            
            const url = `${baseUrl}?serviceKey=${this.KMA_API_KEY}&numOfRows=10&pageNo=1&dataType=JSON&base_date=${baseDate}&base_time=${baseTime}&nx=${grid.x}&ny=${grid.y}`;
            
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error(`기상청 API 오류: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (data.response.header.resultCode !== '00') {
                throw new Error(`기상청 API 응답 오류: ${data.response.header.resultMsg}`);
            }
            
            return this.parseKMAData(data);
        } catch (error) {
            console.error('기상청 API 오류:', error);
            return null;
        }
    },

    // 위경도를 기상청 격자 좌표로 변환
    convertToGrid: function(lat, lon) {
        const RE = 6371.00877;
        const GRID = 5.0;
        const SLAT1 = 30.0;
        const SLAT2 = 60.0;
        const OLON = 126.0;
        const OLAT = 38.0;
        const XO = 43;
        const YO = 136;

        const DEGRAD = Math.PI / 180.0;
        const re = RE / GRID;
        const slat1 = SLAT1 * DEGRAD;
        const slat2 = SLAT2 * DEGRAD;
        const olon = OLON * DEGRAD;
        const olat = OLAT * DEGRAD;

        let sn = Math.tan(Math.PI * 0.25 + slat2 * 0.5) / Math.tan(Math.PI * 0.25 + slat1 * 0.5);
        sn = Math.log(Math.cos(slat1) / Math.cos(slat2)) / Math.log(sn);
        let sf = Math.tan(Math.PI * 0.25 + slat1 * 0.5);
        sf = Math.pow(sf, sn) * Math.cos(slat1) / sn;
        let ro = Math.tan(Math.PI * 0.25 + olat * 0.5);
        ro = re * sf / Math.pow(ro, sn);

        let ra = Math.tan(Math.PI * 0.25 + (lat) * DEGRAD * 0.5);
        ra = re * sf / Math.pow(ra, sn);
        let theta = lon * DEGRAD - olon;
        if (theta > Math.PI) theta -= 2.0 * Math.PI;
        if (theta < -Math.PI) theta += 2.0 * Math.PI;
        theta *= sn;

        const x = Math.floor(ra * Math.sin(theta) + XO + 0.5);
        const y = Math.floor(ro - ra * Math.cos(theta) + YO + 0.5);

        return { x, y };
    },

    // 기상청 데이터 파싱
    parseKMAData: function(data) {
        const items = data.response.body.items.item;
        const weatherData = {};
        
        items.forEach(item => {
            weatherData[item.category] = item.obsrValue;
        });
        
        return {
            source: '기상청',
            temperature: parseFloat(weatherData.T1H) || 0,  // 기온
            humidity: parseFloat(weatherData.REH) || 0,      // 습도
            windSpeed: parseFloat(weatherData.WSD) || 0,      // 풍속
            precipitation: parseFloat(weatherData.RN1) || 0,  // 강수량
            weatherMain: this.interpretKMAWeather(weatherData)
        };
    },

    // 기상청 데이터를 날씨 상태로 해석
    interpretKMAWeather: function(data) {
        const pty = data.PTY; // 강수형태
        const sky = data.SKY; // 하늘상태
        
        if (pty === '1' || pty === '2' || pty === '5' || pty === '6') {
            return 'Rain';
        } else if (pty === '3' || pty === '7') {
            return 'Snow';
        } else if (sky === '1') {
            return 'Clear';
        } else if (sky === '3') {
            return 'Clouds';
        } else if (sky === '4') {
            return 'Clouds';
        }
        
        return 'Clear';
    },

    // 날짜 포맷 (YYYYMMDD)
    formatDate: function(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}${month}${day}`;
    },

    // 시간 포맷 (HHMM)
    formatTime: function(date) {
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${hours}${minutes}`;
    },

    // 두 API 데이터 교차 검증
    crossValidateWeather: async function(lat, lon) {
        const [openWeatherData, kmaData] = await Promise.all([
            this.getOpenWeatherData(lat, lon),
            this.getKMAData(lat, lon)
        ]);

        // OpenWeather 우선 정책
        if (openWeatherData && kmaData) {
            console.log('두 API 데이터 모두 가져옴. OpenWeather 우선 사용.');
            console.log('OpenWeather:', openWeatherData);
            console.log('기상청:', kmaData);
            
            // OpenWeather를 기본으로 하되, 기상청 데이터와 비교
            const comparison = {
                openweather: openWeatherData,
                kma: kmaData,
                tempDiff: Math.abs(openWeatherData.temperature - kmaData.temperature)
            };
            
            console.log('온도 차이:', comparison.tempDiff, '°C');
            
            return openWeatherData;
        } else if (openWeatherData) {
            console.log('OpenWeather 데이터만 사용 가능');
            return openWeatherData;
        } else if (kmaData) {
            console.log('기상청 데이터만 사용 가능');
            return kmaData;
        } else {
            console.error('모든 API에서 데이터를 가져오지 못했습니다.');
            return this.getDemoData();
        }
    },

    // 데모 데이터 (API 키가 없을 때)
    getDemoData: function() {
        const demoWeathers = [
            {
                source: 'Demo (OpenWeather 형식)',
                temperature: 18,
                feelsLike: 16,
                humidity: 65,
                windSpeed: 3.5,
                weatherMain: 'Clear',
                weatherDescription: '맑음',
                city: '서울',
                icon: '01d'
            },
            {
                source: 'Demo (OpenWeather 형식)',
                temperature: 12,
                feelsLike: 10,
                humidity: 80,
                windSpeed: 5.2,
                weatherMain: 'Rain',
                weatherDescription: '비',
                city: '서울',
                icon: '10d'
            },
            {
                source: 'Demo (OpenWeather 형식)',
                temperature: -2,
                feelsLike: -5,
                humidity: 70,
                windSpeed: 2.8,
                weatherMain: 'Snow',
                weatherDescription: '눈',
                city: '서울',
                icon: '13d'
            },
            {
                source: 'Demo (OpenWeather 형식)',
                temperature: 15,
                feelsLike: 14,
                humidity: 60,
                windSpeed: 4.1,
                weatherMain: 'Clouds',
                weatherDescription: '구름 많음',
                city: '서울',
                icon: '03d'
            }
        ];

        // 랜덤하게 하나 선택
        return demoWeathers[Math.floor(Math.random() * demoWeathers.length)];
    },

    // 메인 날씨 가져오기 함수
    fetchWeather: async function() {
        try {
            await this.getUserLocation();
            const weatherData = await this.crossValidateWeather(
                this.currentLocation.lat,
                this.currentLocation.lon
            );
            
            return weatherData;
        } catch (error) {
            console.error('날씨 정보 가져오기 오류:', error);
            throw error;
        }
    }
};

// 전역 접근을 위한 export
window.WeatherAPI = WeatherAPI;
