
예언구슬 통합 프로젝트 (OpenAI 포함)
===================================

위치는: /mnt/data/예언구슬_통합프로젝트_final_with_openai

실행 방법:
1) Python 3.10+ 권장 환경에서 가상환경을 만드세요.
   python -m venv venv
   source venv/bin/activate   # macOS/Linux
   venv\Scripts\activate    # Windows

2) 백엔드 의존성 설치:
   cd backend
   pip install -r requirements.txt

3) OpenAI 키 설정 (.env 파일에 넣으세요):
   backend/.env 파일 안에 다음처럼 설정:
   OPENAI_API_KEY=sk-...

4) DB 테이블 생성 및 서버 실행:
   uvicorn main:app --reload

5) 접속:
   / -> 예언구슬 원본 index.html (루트)
   /ai-fashion -> AI-Fashion 원본 index.html
   API 예시: GET /api/recommend/ai?user_id=1

주의:
- 원본 프론트엔드 파일은 frontend/ 폴더 내부에 원본 그대로 들어 있습니다.
- OpenAI Image API는 계정과 사용가능 여부에 따라 동작하지 않을 수 있습니다.
