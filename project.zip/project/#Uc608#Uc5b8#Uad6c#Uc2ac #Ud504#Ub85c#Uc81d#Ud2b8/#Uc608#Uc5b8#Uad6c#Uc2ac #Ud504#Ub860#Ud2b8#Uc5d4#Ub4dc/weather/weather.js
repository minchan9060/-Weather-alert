document.addEventListener("DOMContentLoaded", async () => {
    const apiKey = "X2EpiN9GMhDbkuvZfjpStwTm9WBB4xEs"; // ✅ Tomorrow.io API Key
    const chartCanvas = document.getElementById("forecastChart");
    const predictionBox = document.getElementById("predictionBox");
  
    if (!navigator.geolocation) {
      predictionBox.innerText = "❌ 위치 정보를 가져올 수 없습니다.";
      return;
    }
  
    navigator.geolocation.getCurrentPosition(success, error);
  
    async function success(position) {
      const { latitude, longitude } = position.coords;
  
      try {
        // ✅ Tomorrow.io V4 Forecast API
        const url = `https://api.tomorrow.io/v4/weather/forecast?location=${latitude},${longitude}&apikey=${apiKey}`;
        const res = await fetch(url);
        const data = await res.json();
  
        console.log("📡 Tomorrow.io 응답:", data);
  
        if (!data.timelines || !data.timelines.daily) {
          throw new Error("예보 데이터가 없습니다.");
        }
  
        // 🔹 7일치 데이터 파싱
        const days = data.timelines.daily.slice(0, 7);
        const labels = days.map((d, i) => {
          const date = new Date(d.time);
          return `${date.getMonth() + 1}/${date.getDate()}`;
        });
        const temps = days.map((d) => d.values.temperatureAvg);
        const desc = days.map((d) => d.values.weatherCodeMax);
  
        // ✅ Chart.js 그래프
        new Chart(chartCanvas, {
          type: "line",
          data: {
            labels: labels,
            datasets: [
              {
                label: "평균 기온 (°C)",
                data: temps,
                borderColor: "#b57bff",
                backgroundColor: "rgba(181, 123, 255, 0.2)",
                borderWidth: 3,
                tension: 0.4,
                fill: true,
                pointRadius: 5,
                pointBackgroundColor: "#e3caff",
              },
            ],
          },
          options: {
            plugins: {
              legend: { labels: { color: "#fff" } },
            },
            scales: {
              x: { ticks: { color: "#e0caff" } },
              y: { ticks: { color: "#e0caff" } },
            },
          },
        });
  
        // 🔮 예언 멘트 생성
        const maxTemp = Math.max(...temps);
        const hottestDay = temps.indexOf(maxTemp);
        const date = labels[hottestDay];
  
        predictionBox.innerHTML = `
          🔮 <b>${date}</b> (${maxTemp}°C) — 가장 뜨거운 날입니다.<br>
          구슬이 강한 태양의 기운을 감지했어요... ☀️
        `;
      } catch (err) {
        console.error("🚨 오류 발생:", err);
        predictionBox.innerText = "❌ 구슬이 미래를 읽지 못했습니다.";
      }
    }
  
    function error() {
      predictionBox.innerText = "❌ 위치 정보를 불러오지 못했습니다.";
    }
  });
  