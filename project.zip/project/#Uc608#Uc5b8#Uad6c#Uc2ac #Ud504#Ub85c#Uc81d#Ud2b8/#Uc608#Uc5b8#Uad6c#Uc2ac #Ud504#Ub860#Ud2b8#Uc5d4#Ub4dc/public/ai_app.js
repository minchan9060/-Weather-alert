// API 기본 URL
const API_BASE_URL = window.location.origin;

// DOM 요소
const userForm = document.getElementById('userForm');
const submitBtn = document.getElementById('submitBtn');
const btnText = document.querySelector('.btn-text');
const btnLoader = document.querySelector('.btn-loader');
const resultSection = document.getElementById('resultSection');
const errorMessage = document.getElementById('errorMessage');
const errorText = document.getElementById('errorText');

// 날씨 아이콘 매핑
const weatherIcons = {
    'Clear': '☀️',
    'Clouds': '☁️',
    'Rain': '🌧️',
    'Drizzle': '🌦️',
    'Thunderstorm': '⛈️',
    'Snow': '❄️',
    'Mist': '🌫️',
    'Fog': '🌫️',
    'Haze': '🌫️',
    'Dust': '💨',
    'Sand': '💨',
    'Smoke': '💨'
};

/**
 * 에러 메시지 표시
 */
function showError(message) {
    errorText.textContent = message;
    errorMessage.style.display = 'block';
    
    // 3초 후 자동 숨김
    setTimeout(() => {
        errorMessage.style.display = 'none';
    }, 5000);
    
    // 결과 섹션 숨김
    resultSection.style.display = 'none';
}

/**
 * 로딩 상태 토글
 */
function toggleLoading(isLoading) {
    if (isLoading) {
        submitBtn.disabled = true;
        btnText.style.display = 'none';
        btnLoader.style.display = 'flex';
    } else {
        submitBtn.disabled = false;
        btnText.style.display = 'block';
        btnLoader.style.display = 'none';
    }
}

/**
 * 날씨 정보 렌더링
 */
function renderWeather(weather) {
    document.getElementById('cityName').textContent = weather.city;
    document.getElementById('weatherDesc').textContent = weather.description;
    document.getElementById('tempMain').textContent = `${weather.temperature}°C`;
    document.getElementById('feelsLike').textContent = `${weather.feelsLike}°C`;
    document.getElementById('humidity').textContent = `${weather.humidity}%`;
    document.getElementById('windSpeed').textContent = `${weather.windSpeed} m/s`;
    document.getElementById('discomfortIndex').textContent = weather.discomfortIndex;
    
    // 날씨 아이콘 설정
    const icon = weatherIcons[weather.weather] || '🌤️';
    document.getElementById('weatherIcon').textContent = icon;
}

/**
 * 추천 요약 렌더링
 */
function renderRecommendation(recommendation) {
    document.getElementById('summaryText').textContent = recommendation.summary;
    document.getElementById('reasonText').textContent = recommendation.reason;
    
    // 팁 리스트 렌더링
    const tipsList = document.getElementById('tipsList');
    tipsList.innerHTML = '';
    recommendation.tips.forEach(tip => {
        const li = document.createElement('li');
        li.textContent = tip;
        tipsList.appendChild(li);
    });
}

/**
 * 아이템 카드 렌더링
 */
function renderItems(items) {
    const itemsGrid = document.getElementById('itemsGrid');
    itemsGrid.innerHTML = '';
    
    // 카테고리별 이모지 매핑
    const categoryEmojis = {
        '상의': '👕',
        '하의': '👖',
        '아우터': '🧥',
        '신발': '👟',
        '액세서리': '👜'
    };
    
    items.forEach((item, index) => {
        const card = document.createElement('div');
        card.className = 'item-card';
        card.style.animationDelay = `${index * 0.1}s`;
        
        const emoji = categoryEmojis[item.category] || '👔';
        
        card.innerHTML = `
            <img src="${item.imageUrl}" alt="${item.itemName}" class="item-image" 
                 onerror="this.src='https://via.placeholder.com/300x400/667eea/ffffff?text=${encodeURIComponent(emoji + ' ' + item.category)}'">
            <div class="item-content">
                <span class="item-category">${item.category}</span>
                <h3 class="item-name">${item.itemName}</h3>
                <p class="item-description">${item.description}</p>
                <a href="${item.shopLink}" target="_blank" rel="noopener noreferrer" class="item-link">
                    🛒 무신사에서 구매하기
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                    </svg>
                </a>
            </div>
        `;
        
        itemsGrid.appendChild(card);
    });
}

/**
 * 폼 제출 핸들러
 */
userForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // 에러 메시지 숨김
    errorMessage.style.display = 'none';
    
    // 폼 데이터 수집
    const formData = new FormData(userForm);
    const userData = {
        age: parseInt(formData.get('age')),
        gender: formData.get('gender'),
        preferredStyle: formData.get('preferredStyle'),
        recentActivity: formData.get('recentActivity'),
        bodyType: formData.get('bodyType') || '보통',
        colorPreference: formData.get('colorPreference') || '다양함'
    };
    
    const city = formData.get('city');
    
    // 입력 검증
    if (!userData.age || !userData.gender || !userData.preferredStyle || !userData.recentActivity) {
        showError('모든 필수 항목을 입력해주세요.');
        return;
    }
    
    if (userData.age < 10 || userData.age > 100) {
        showError('나이는 10세에서 100세 사이여야 합니다.');
        return;
    }
    
    // 로딩 시작
    toggleLoading(true);
    
    try {
        // API 호출
        const response = await fetch(`${API_BASE_URL}/api/recommend`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                city: city,
                userData: userData
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || '추천을 생성하는데 실패했습니다.');
        }
        
        if (!data.success) {
            throw new Error(data.error || '서버에서 오류가 발생했습니다.');
        }
        
        // 결과 렌더링
        renderWeather(data.weather);
        renderRecommendation(data.recommendation);
        renderItems(data.recommendation.items);
        
        // 결과 섹션 표시
        resultSection.style.display = 'block';
        
        // 결과 섹션으로 스크롤
        setTimeout(() => {
            resultSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 300);
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message || '추천을 생성하는 중 오류가 발생했습니다. 다시 시도해주세요.');
    } finally {
        // 로딩 종료
        toggleLoading(false);
    }
});

/**
 * 페이지 로드 시 초기화
 */
document.addEventListener('DOMContentLoaded', () => {
    console.log('AI 패션 스타일리스트가 준비되었습니다! ✨');
    
    // 서버 헬스체크
    fetch(`${API_BASE_URL}/api/health`)
        .then(response => response.json())
        .then(data => {
            console.log('서버 상태:', data.status);
        })
        .catch(error => {
            console.warn('서버 연결 확인 실패:', error);
        });
});

/**
 * 입력 필드 애니메이션
 */
const inputs = document.querySelectorAll('input, select');
inputs.forEach(input => {
    input.addEventListener('focus', function() {
        this.parentElement.style.transform = 'translateY(-2px)';
    });
    
    input.addEventListener('blur', function() {
        this.parentElement.style.transform = 'translateY(0)';
    });
});

/**
 * 실시간 입력 검증
 */
const ageInput = document.getElementById('age');
ageInput.addEventListener('input', function() {
    const value = parseInt(this.value);
    if (value < 10 || value > 100) {
        this.style.borderColor = '#f56565';
    } else {
        this.style.borderColor = '#48bb78';
    }
});

/**
 * 폼 필드 변경 시 에러 메시지 자동 숨김
 */
const formFields = userForm.querySelectorAll('input, select');
formFields.forEach(field => {
    field.addEventListener('change', () => {
        if (errorMessage.style.display === 'block') {
            errorMessage.style.display = 'none';
        }
    });
});

/**
 * 키보드 단축키 (Enter로 폼 제출)
 */
document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
        const activeElement = document.activeElement;
        if (activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'SELECT')) {
            e.preventDefault();
            userForm.dispatchEvent(new Event('submit'));
        }
    }
});

/**
 * 날씨 아이콘 애니메이션
 */
function animateWeatherIcon() {
    const weatherIcon = document.getElementById('weatherIcon');
    if (weatherIcon) {
        weatherIcon.style.animation = 'none';
        setTimeout(() => {
            weatherIcon.style.animation = 'weather-bounce 2s ease-in-out infinite';
        }, 10);
    }
}

/**
 * 스크롤 애니메이션
 */
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// 관찰할 요소들
const animatedElements = document.querySelectorAll('.card, .item-card');
animatedElements.forEach(el => {
    observer.observe(el);
});
