document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("surveyForm");
  
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
  
      // 설문 데이터 수집
      const formData = new FormData(form);
      const answers = {};
      formData.forEach((value, key) => {
        if (answers[key]) {
          // 체크박스 다중선택 처리
          if (!Array.isArray(answers[key])) answers[key] = [answers[key]];
          answers[key].push(value);
        } else {
          answers[key] = value;
        }
      });
  
      try {
        const response = await fetch("http://127.0.0.1:8000/survey", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(answers),
        });
  
        if (response.ok) {
          alert("설문조사가 저장되었습니다! 🎉");
          window.location.href = "../main_page/main.html"; // 메인 페이지로 이동
        } else {
          const data = await response.json();
          alert("설문 실패: " + (data.detail || "서버 오류"));
        }
      } catch (error) {
        console.error(error);
        alert("서버 연결 실패!");
      }
    });
  });
  