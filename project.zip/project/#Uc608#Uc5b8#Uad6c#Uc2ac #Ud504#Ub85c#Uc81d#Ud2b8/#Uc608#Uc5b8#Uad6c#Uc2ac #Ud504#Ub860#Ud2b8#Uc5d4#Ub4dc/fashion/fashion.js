// ========================================
// AI 패션 추천 시스템
// ========================================

class FashionAdvisor {
    constructor() {
        this.weatherData = null;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadWeatherData();
    }

    setupEventListeners() {
        const recommendBtn = document.getElementById('recommendBtn');
        if (recommendBtn) {
            recommendBtn.addEventListener('click', () => this.generateRecommendations());
        }
    }

    // 날씨 데이터 로드
    async loadWeatherData() {
        const loadingOverlay = document.getElementById('loadingOverlay');
        
        try {
            loadingOverlay.classList.add('active');

            // 위치 권한 요청
            const position = await this.getLocation();
            const { latitude, longitude } = position.coords;

            // Tomorrow.io API를 사용한 날씨 데이터 가져오기
            const weather = await this.fetchWeather(latitude, longitude);
            
            this.weatherData = weather;
            this.displayWeatherInfo(weather);
            
        } catch (error) {
            console.error('날씨 정보 로드 실패:', error);
            this.showDemoWeather();
        } finally {
            loadingOverlay.classList.remove('active');
        }
    }

    // 위치 정보 가져오기
    getLocation() {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject(new Error('Geolocation is not supported'));
                return;
            }

            navigator.geolocation.getCurrentPosition(resolve, reject, {
                timeout: 10000,
                enableHighAccuracy: true
            });
        });
    }

    // 날씨 데이터 가져오기 (Tomorrow.io API)
    async fetchWeather(lat, lon) {
        // Tomorrow.io API 키 (실제 사용 시 환경 변수로 관리)
        const API_KEY = 'YOUR_TOMORROW_IO_API_KEY';
        const url = `https://api.tomorrow.io/v4/weather/realtime?location=${lat},${lon}&apikey=${API_KEY}`;

        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Weather API request failed');
            }
            
            const data = await response.json();
            return this.parseWeatherData(data);
        } catch (error) {
            console.error('날씨 API 오류:', error);
            // 데모 데이터 사용
            return this.getDemoWeather();
        }
    }

    // 날씨 데이터 파싱
    parseWeatherData(data) {
        const values = data.data.values;
        
        return {
            temperature: Math.round(values.temperature),
            feelsLike: Math.round(values.temperatureApparent),
            humidity: Math.round(values.humidity),
            windSpeed: Math.round(values.windSpeed),
            weatherCode: values.weatherCode,
            description: this.getWeatherDescription(values.weatherCode),
            icon: this.getWeatherIcon(values.weatherCode)
        };
    }

    // 날씨 코드를 설명으로 변환
    getWeatherDescription(code) {
        const descriptions = {
            1000: '맑음',
            1100: '대체로 맑음',
            1101: '부분적으로 흐림',
            1102: '대체로 흐림',
            2000: '안개',
            4000: '이슬비',
            4001: '비',
            4200: '약한 비',
            4201: '강한 비',
            5000: '눈',
            5001: '진눈깨비',
            8000: '천둥번개'
        };
        return descriptions[code] || '알 수 없음';
    }

    // 날씨 아이콘 가져오기
    getWeatherIcon(code) {
        const icons = {
            1000: '☀️',
            1100: '🌤️',
            1101: '⛅',
            1102: '☁️',
            2000: '🌫️',
            4000: '🌦️',
            4001: '🌧️',
            4200: '🌦️',
            4201: '⛈️',
            5000: '❄️',
            5001: '🌨️',
            8000: '⚡'
        };
        return icons[code] || '🌤️';
    }

    // 데모 날씨 데이터
    getDemoWeather() {
        const scenarios = [
            { temp: 28, feels: 32, humidity: 65, wind: 3, code: 1000, desc: '맑고 더움', icon: '☀️' },
            { temp: 15, feels: 13, humidity: 70, wind: 5, code: 4001, desc: '비 오는 날', icon: '🌧️' },
            { temp: 5, feels: 2, humidity: 50, wind: 8, code: 5000, desc: '눈 오는 날', icon: '❄️' },
            { temp: 22, feels: 22, humidity: 55, wind: 2, code: 1101, desc: '봄날씨', icon: '🌤️' }
        ];
        
        const random = scenarios[Math.floor(Math.random() * scenarios.length)];
        
        return {
            temperature: random.temp,
            feelsLike: random.feels,
            humidity: random.humidity,
            windSpeed: random.wind,
            weatherCode: random.code,
            description: random.desc,
            icon: random.icon
        };
    }

    // 데모 날씨 표시
    showDemoWeather() {
        this.weatherData = this.getDemoWeather();
        this.displayWeatherInfo(this.weatherData);
    }

    // 날씨 정보 표시
    displayWeatherInfo(weather) {
        document.getElementById('weatherIcon').textContent = weather.icon;
        document.getElementById('currentTemp').textContent = `${weather.temperature}°C`;
        document.getElementById('weatherDesc').textContent = weather.description;
        document.getElementById('locationText').textContent = '현재 위치';
        document.getElementById('humidityText').textContent = `${weather.humidity}%`;
        document.getElementById('windText').textContent = `${weather.windSpeed} m/s`;
        document.getElementById('feelsLikeText').textContent = `${weather.feelsLike}°C`;
    }

    // AI 패션 추천 생성
    async generateRecommendations() {
        if (!this.weatherData) {
            alert('날씨 정보를 먼저 불러와주세요.');
            return;
        }

        const loadingOverlay = document.getElementById('loadingOverlay');
        loadingOverlay.classList.add('active');

        // 추천 생성 시뮬레이션 (1.5초 딜레이)
        await new Promise(resolve => setTimeout(resolve, 1500));

        const recommendation = this.analyzeWeatherForFashion(this.weatherData);
        this.displayRecommendations(recommendation);

        loadingOverlay.classList.remove('active');
    }

    // 날씨 분석 및 패션 추천
    analyzeWeatherForFashion(weather) {
        const temp = weather.temperature;
        const code = weather.weatherCode;
        const wind = weather.windSpeed;

        let items = [];
        let tips = [];
        let colors = [];
        let reason = '';

        // 온도별 기본 추천
        if (temp >= 28) {
            // 매우 더움
            reason = `현재 기온이 ${temp}°C로 매우 덥습니다. 시원하고 통풍이 잘 되는 옷차림을 추천합니다.`;
            items = [
                { icon: '👕', name: '반팔 티셔츠', desc: '면 소재의 가벼운 티셔츠' },
                { icon: '🩳', name: '반바지/치마', desc: '시원한 하의' },
                { icon: '🧢', name: '모자', desc: '햇빛 차단용 캡모자' },
                { icon: '🕶️', name: '선글라스', desc: '자외선 차단' }
            ];
            tips = [
                '밝은 색상의 옷을 선택하면 햇빛을 덜 흡수합니다',
                '린넨, 면 등 통풍이 잘 되는 소재를 선택하세요',
                '자외선 차단제를 꼭 바르세요',
                '물을 자주 마시고 그늘에서 휴식하세요'
            ];
            colors = [
                { hex: '#FFFFFF', name: '화이트' },
                { hex: '#87CEEB', name: '스카이블루' },
                { hex: '#FFFACD', name: '레몬' },
                { hex: '#FFE4B5', name: '베이지' }
            ];
        } else if (temp >= 20) {
            // 따뜻함
            reason = `현재 기온이 ${temp}°C로 활동하기 좋은 날씨입니다. 가볍게 겹쳐입기를 추천합니다.`;
            items = [
                { icon: '👔', name: '긴팔 셔츠', desc: '가벼운 긴팔 상의' },
                { icon: '👖', name: '긴바지', desc: '편안한 면바지' },
                { icon: '🧥', name: '가디건', desc: '가벼운 겉옷' },
                { icon: '👟', name: '스니커즈', desc: '편한 운동화' }
            ];
            tips = [
                '아침 저녁으로 쌀쌀할 수 있으니 가디건을 챙기세요',
                '레이어드 스타일로 온도 변화에 대응하세요',
                '밝고 활기찬 컬러를 활용해보세요',
                '가벼운 액세서리로 포인트를 주세요'
            ];
            colors = [
                { hex: '#FF6B6B', name: '코랄' },
                { hex: '#4ECDC4', name: '민트' },
                { hex: '#FFE66D', name: '옐로우' },
                { hex: '#95E1D3', name: '청록색' }
            ];
        } else if (temp >= 10) {
            // 쌀쌀함
            reason = `현재 기온이 ${temp}°C로 쌀쌀합니다. 따뜻한 옷차림을 추천합니다.`;
            items = [
                { icon: '🧥', name: '자켓/점퍼', desc: '따뜻한 겉옷' },
                { icon: '👖', name: '긴바지', desc: '두꺼운 소재의 바지' },
                { icon: '🧣', name: '스카프', desc: '목을 따뜻하게' },
                { icon: '👞', name: '부츠', desc: '발목을 감싸는 신발' }
            ];
            tips = [
                '겹쳐입기로 보온 효과를 높이세요',
                '목, 손목, 발목을 따뜻하게 유지하세요',
                '어두운 톤의 컬러로 차분한 느낌을 연출하세요',
                '바람막이 기능이 있는 겉옷을 선택하세요'
            ];
            colors = [
                { hex: '#8B4513', name: '브라운' },
                { hex: '#2F4F4F', name: '다크그레이' },
                { hex: '#800020', name: '버건디' },
                { hex: '#2C3E50', name: '네이비' }
            ];
        } else {
            // 추움
            reason = `현재 기온이 ${temp}°C로 매우 춥습니다. 두꺼운 방한복을 추천합니다.`;
            items = [
                { icon: '🧥', name: '두꺼운 코트', desc: '패딩/울코트' },
                { icon: '🧤', name: '장갑', desc: '방한 장갑' },
                { icon: '🧣', name: '목도리', desc: '두꺼운 목도리' },
                { icon: '🥾', name: '방한화', desc: '따뜻한 겨울 신발' }
            ];
            tips = [
                '패딩이나 다운 코트로 보온하세요',
                '내복을 착용하면 더 따뜻합니다',
                '모자와 귀마개로 체온 손실을 막으세요',
                '따뜻한 음료를 자주 마시세요'
            ];
            colors = [
                { hex: '#000000', name: '블랙' },
                { hex: '#696969', name: '차콜' },
                { hex: '#8B0000', name: '다크레드' },
                { hex: '#191970', name: '미드나잇블루' }
            ];
        }

        // 날씨 코드별 추가 조정
        if (code >= 4000 && code < 5000) {
            // 비 오는 날
            reason += ' 비가 예상되니 방수 기능이 있는 옷을 선택하세요.';
            items.push({ icon: '☂️', name: '우산', desc: '필수 아이템' });
            items.push({ icon: '🥾', name: '방수 신발', desc: '발이 젖지 않도록' });
            tips.push('방수 소재의 겉옷을 선택하세요');
            tips.push('우산을 꼭 챙기세요');
        } else if (code >= 5000 && code < 6000) {
            // 눈 오는 날
            reason += ' 눈이 예상되니 미끄럼 방지 신발과 방한복을 착용하세요.';
            items.push({ icon: '🧤', name: '방한 장갑', desc: '손을 따뜻하게' });
            items.push({ icon: '🥾', name: '논슬립 부츠', desc: '미끄럼 방지' });
            tips.push('미끄럽지 않은 신발을 신으세요');
            tips.push('여러 겹 겹쳐입어 보온하세요');
        }

        // 바람이 강한 경우
        if (wind > 5) {
            tips.push(`풍속이 ${wind} m/s로 강하니 바람막이를 챙기세요`);
        }

        return { items, tips, colors, reason };
    }

    // 추천 결과 표시
    displayRecommendations(recommendation) {
        const recommendationsDiv = document.getElementById('recommendations');
        const reasonText = document.getElementById('reasonText');
        const fashionItems = document.getElementById('fashionItems');
        const tipsList = document.getElementById('tipsList');
        const colorsList = document.getElementById('colorsList');

        // 추천 이유 표시
        reasonText.textContent = recommendation.reason;

        // 패션 아이템 표시
        fashionItems.innerHTML = '';
        recommendation.items.forEach(item => {
            const itemDiv = document.createElement('div');
            itemDiv.className = 'fashion-item';
            itemDiv.innerHTML = `
                <div class="item-icon">${item.icon}</div>
                <div class="item-name">${item.name}</div>
                <div class="item-description">${item.desc}</div>
            `;
            fashionItems.appendChild(itemDiv);
        });

        // 스타일 팁 표시
        tipsList.innerHTML = '';
        recommendation.tips.forEach(tip => {
            const li = document.createElement('li');
            li.textContent = tip;
            tipsList.appendChild(li);
        });

        // 컬러 팔레트 표시
        colorsList.innerHTML = '';
        recommendation.colors.forEach(color => {
            const colorDiv = document.createElement('div');
            colorDiv.className = 'color-item';
            colorDiv.innerHTML = `
                <div class="color-swatch" style="background-color: ${color.hex}"></div>
                <div class="color-name">${color.name}</div>
            `;
            colorsList.appendChild(colorDiv);
        });

        // 추천 섹션 표시
        recommendationsDiv.style.display = 'block';
        
        // 스크롤 애니메이션
        recommendationsDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', () => {
    new FashionAdvisor();
});
